#!/usr/bin/perl
# Met à jour consigne.md sur place (une seule fois, sans rien écraser de ce que tu y as personnalisé).
use strict; use warnings; use utf8;
my $f = $ARGV[0] || 'consigne.md';
exit 0 unless -f $f;
open(my $in, '<:encoding(UTF-8)', $f) or exit 0; local $/; my $c = <$in>; close $in;
my $o = $c;
# 1) analyse du plus ancien au plus récent, 10 mails par passage
my $old = "3. Pour chaque brouillon technique restant (5 maximum par passage) :";
my $new = "3. Classe d'abord les brouillons techniques restants du plus ancien au plus récent (date du mail d'origine, visible dans le brouillon ou dans le fil ; à défaut, ordre croissant du messageId), puis prends les 10 plus anciens. Pour chaque brouillon technique retenu (10 maximum par passage, toujours dans cet ordre) :";
my $i = index($c, $old); substr($c, $i, length($old)) = $new if $i >= 0;
# 2) clé "recherche" dans la fiche (critères d'un client qui cherche un bien)
if (index($c, '"recherche" (') < 0 && -f 'recherche-cle.txt') {
  open(my $k, '<:encoding(UTF-8)', 'recherche-cle.txt') or exit 0; my $cle = <$k>; close $k; $cle =~ s/\s+$//;
  my $anchor = '"brouillon_cree" (true ou false)';
  my $j = index($c, $anchor);
  substr($c, $j, 0) = $cle . ', ' if $j >= 0;
}
if ($c ne $o) {
  open(my $b, '>:encoding(UTF-8)', "$f.bak-maj") or exit 0; print $b $o; close $b;
  open(my $out, '>:encoding(UTF-8)', $f) or exit 0; print $out $c; close $out;
}

(function(){
  var fiches = {};
  var loaded = {};
  var selected = null;
  var seen = {};
  try { seen = JSON.parse(localStorage.getItem('godeye_seen') || '{}'); } catch(e) {}
  var done = {};
  var filter = 'todo';
  try { done = JSON.parse(localStorage.getItem('godeye_done') || '{}'); } catch(e) {}
  function setDone(id, v){
    if (v) { done[id] = 1; if (typeof relances !== 'undefined' && relances && relances[id]) { delete relances[id]; try { localStorage.setItem('godeye_relances', JSON.stringify(relances)); } catch(e) {} } } else delete done[id];
    try { localStorage.setItem('godeye_done', JSON.stringify(done)); } catch(e) {}
  }
  var DEL_URL = GE_CONFIG.URL;
  var DEL_TOKEN = GE_CONFIG.TOKEN;
  function moi(m){ return String(m || '').toLowerCase().indexOf(String(GE_CONFIG.MAIL).toLowerCase()) >= 0; }
  function say(t){
    var m = document.getElementById('maj');
    if (m) m.textContent = t;
    window.__keep = true; setTimeout(function(){ window.__keep = false; }, 8000);
  }
  function deleteDrafts(id){
    say('Suppression du brouillon…');
    try { fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=lu&p=' + encodeURIComponent(id), {credentials:'include'}).catch(function(){}); } catch (e) {}
    fetch(DEL_URL + '?t=' + DEL_TOKEN + '&id=' + encodeURIComponent(id), {credentials:'include'})
      .then(function(r){ return r.json(); })
      .then(function(j){
        if (!j.ok) say('Brouillon non supprimé (refusé)');
        else say(j.n ? 'Brouillon supprimé' : 'Aucun brouillon à supprimer');
      })
      .catch(function(){ say('Brouillon non supprimé (erreur)'); });
  }
  var LOCAL = 'http://127.0.0.1:47321';
  var LTOK = GE_CONFIG.LTOK;
  var reps = {};
  var repsLoaded = {};
  var pending = {};
  var texts = {};
  var rdvs = {}; var rdvOpen = {};
  window.godeyeRep = function(r, name){
    if (!r || !r.key) return;
    r.ts = parseInt(name, 10) || 0;
    if (!reps[r.key] || reps[r.key].ts < r.ts) reps[r.key] = r;
    render();
  };
  function localPost(path, obj){
    return fetch(LOCAL + path, {method:'POST', headers:{'X-GodEye': LTOK, 'Content-Type':'text/plain'}, body: obj ? JSON.stringify(obj) : ''});
  }
  var pjs = {};
  function pjOf(key){ return pjs[key] || (pjs[key] = {files: [], armed: false, busy: false, msg: ''}); }
  function pjArm(key){ var p = pjOf(key); if (p.files.length) p.armed = true; }
  function pjRead(file){
    return new Promise(function(res, rej){
      var fr = new FileReader();
      fr.onload = function(){ res(String(fr.result).split(',')[1] || ''); };
      fr.onerror = function(){ rej(new Error('lecture')); };
      fr.readAsDataURL(file);
    });
  }
  function pjGo(key, rp){
    var p = pjOf(key);
    if (p.busy || !p.files.length) return;
    p.armed = false;
    if (!rp || !rp.brouillon_id) { p.msg = 'Identifiant du brouillon manquant : joins le fichier à la main dans Gmail.'; return; }
    var list = p.files.slice();
    p.busy = true; p.msg = 'Ajout de la pièce jointe au brouillon…';
    var warn = false;
    list.reduce(function(chain, file){
      return chain.then(function(){
        return pjRead(file).then(function(b64){
          return fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=pj', {method:'POST', credentials:'include', headers:{'Content-Type':'text/plain'}, body: JSON.stringify({draft: rp.brouillon_id, name: file.name, type: file.type || 'application/octet-stream', data: b64})});
        }).then(function(r){ return r.json(); }).then(function(j){
          if (!j.ok) throw new Error(j.err || 'refus');
          if (j.threadOk === false) warn = true;
        });
      });
    }, Promise.resolve()).then(function(){
      p.files = []; p.busy = false;
      p.msg = warn ? 'Pièce jointe ajoutée. Vérifie dans Gmail que le brouillon est toujours dans le fil.' : (list.length > 1 ? 'Pièces jointes ajoutées au brouillon.' : 'Pièce jointe ajoutée au brouillon.');
      render();
    }).catch(function(e){
      p.busy = false;
      p.msg = 'Pièce jointe non ajoutée (' + (e && e.message ? e.message : 'erreur') + '). Joins-la à la main dans Gmail.';
      render();
    });
  }
  function pjDraw(bar, key, getRep){
    var p = pjOf(key);
    bar.textContent = '';
    var inp = document.createElement('input');
    inp.type = 'file'; inp.multiple = true; inp.style.display = 'none';
    var bt = el('button','btn pjclip',''); bt.type = 'button';
    bt.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#E8B84A" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>Pièce jointe';
    bt.title = 'Joindre un fichier'; bt.setAttribute('aria-label', 'Joindre un fichier');
    bt.addEventListener('click', function(){ inp.click(); });
    inp.addEventListener('change', function(){
      var big = false;
      Array.prototype.forEach.call(inp.files, function(fl){ if (fl.size > 15 * 1024 * 1024) big = true; else p.files.push(fl); });
      p.msg = big ? 'Fichier trop lourd (15 Mo maximum).' : '';
      inp.value = '';
      pjDraw(bar, key, getRep);
    });
    bar.appendChild(bt); bar.appendChild(inp);
    p.files.forEach(function(fl, i){
      var ch = el('button','btn undo', fl.name + ' ✕'); ch.type = 'button'; ch.title = 'Retirer';
      ch.addEventListener('click', function(){ p.files.splice(i, 1); pjDraw(bar, key, getRep); });
      bar.appendChild(ch);
    });
    var rp = getRep ? getRep() : null;
    if (p.files.length && rp && !p.busy) {
      var go = el('button','btn send','Ajouter au brouillon ci-dessus'); go.type = 'button';
      go.addEventListener('click', function(){ pjGo(key, rp); pjDraw(bar, key, getRep); });
      bar.appendChild(go);
    }
    if (p.msg) bar.appendChild(el('div','muted', p.msg));
  }
  // ---- envoi direct et programmé des brouillons (via Apps Script, jamais sans clic) ----
  var envois = {}, envInfo = {}, envInfoBusy = {}, envUi = {}, envSig = '';
  var ENV_VIEUX = 'script Apps Script à mettre à jour';
  function envPad(n){ return (n < 10 ? '0' : '') + n; }
  function envHeure(d){ return d.getHours() + 'h' + (d.getMinutes() ? envPad(d.getMinutes()) : ''); }
  function envFmt(ts){ var d = new Date(ts); return d.toLocaleDateString('fr-FR', {weekday: 'long', day: 'numeric', month: 'short'}) + ' à ' + envHeure(d); }
  function envCourt(ts){
    var d = new Date(ts);
    if (d.toDateString() === new Date().toDateString()) return envHeure(d);
    return d.toLocaleDateString('fr-FR', {weekday: 'short'}) + ' ' + envHeure(d);
  }
  function envDV(d){ return d.getFullYear() + '-' + envPad(d.getMonth() + 1) + '-' + envPad(d.getDate()); }
  function envHV(d){ return envPad(d.getHours()) + ':' + envPad(d.getMinutes()); }
  function envChips(now){
    var jours = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    var a830 = function(add){ var x = new Date(now.getTime()); x.setDate(x.getDate() + add); x.setHours(8, 30, 0, 0); return x; };
    var in1 = new Date(now.getTime() + 3600000); in1.setSeconds(0, 0); in1.setMinutes(Math.ceil(in1.getMinutes() / 5) * 5);
    var add = a830(1).getDay() === 6 ? 2 : 1;
    var dem = a830(add);
    var out = [{l: 'Dans 1 h', d: in1}, {l: (add === 1 ? 'Demain' : jours[dem.getDay()]) + ' 8h30', d: dem}];
    var k = 1; while (a830(k).getDay() !== 1) k++;
    var lun = a830(k);
    if (lun.getTime() !== dem.getTime()) out.push({l: 'Lundi 8h30', d: lun});
    return out;
  }
  function envPost(act, obj){
    return fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=' + act, {method:'POST', credentials:'include', headers:{'Content-Type':'text/plain'}, body: JSON.stringify(obj)}).then(function(r){ return r.json(); });
  }
  // Contacts proposés quand on tape un destinataire : expéditeurs des mails déjà analysés.
  function contactsListe(){
    var me = String(GE_CONFIG.MAIL || '').toLowerCase(), map = {};
    Object.keys(fiches).forEach(function(k){
      var f = fiches[k], em = adrDe(f).toLowerCase();
      if (!em || em === me || /no-?reply|noreply|notification|mailer-daemon|donotreply/.test(em)) return;
      var nom = nomDe(f); if (nom.indexOf('@') >= 0) nom = '';
      var t = Date.parse(f.date || '') || 0, c = map[em];
      if (!c) c = map[em] = {email: em, nom: nom, bien: '', t: 0};
      if (nom && (!c.nom || t >= c.t)) c.nom = nom;
      if (t >= c.t) { c.t = t; if (f.bien) c.bien = String(f.bien).replace(/\s*\(.*$/, ''); }
    });
    return Object.keys(map).map(function(k){ return map[k]; }).sort(function(a, b){ return b.t - a.t; });
  }
  function foldS(x){ return String(x || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function suggestAttach(inp, host, opt){
    opt = opt || {};
    var dd = el('div', 'sugg'); dd.style.display = 'none'; host.appendChild(dd);
    var cur = [], sel = -1;
    function hide(){ dd.style.display = 'none'; sel = -1; }
    function tokStart(){ return opt.multi ? inp.value.lastIndexOf(',') + 1 : 0; }
    function pick(c){
      if (opt.multi) { var st0 = tokStart(); inp.value = inp.value.substring(0, st0).replace(/\s*$/, st0 ? ' ' : '') + c.email + ', '; }
      else inp.value = (opt.plain || !c.nom) ? c.email : c.nom + ' <' + c.email + '>';
      hide(); inp.focus();
      try { inp.dispatchEvent(new Event('input', {bubbles: true})); } catch(e) {}
    }
    function paint(){
      Array.prototype.forEach.call(dd.children, function(n, i){ n.classList.toggle('on', i === sel); });
    }
    function show(){
      var q = foldS(opt.multi ? inp.value.substring(tokStart()) : inp.value).trim();
      if (q.length < 2 || /[<>]/.test(q) || /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/.test(q)) { hide(); return; }
      var toks = q.split(/\s+/);
      cur = contactsListe().filter(function(c){
        var hay = foldS(c.nom + ' ' + c.email);
        return toks.every(function(t){ return hay.indexOf(t) >= 0; });
      }).slice(0, 6);
      dd.textContent = '';
      if (!cur.length) { hide(); return; }
      cur.forEach(function(c){
        var o = el('div', 'sopt');
        o.appendChild(el('b', null, c.nom || c.email));
        o.appendChild(el('span', null, (c.nom ? c.email : '') + (c.bien ? (c.nom ? ' · ' : '') + c.bien : '')));
        o.addEventListener('mousedown', function(e){ e.preventDefault(); pick(c); });
        dd.appendChild(o);
      });
      sel = 0; paint(); dd.style.display = 'block';
    }
    inp.addEventListener('input', show);
    inp.addEventListener('focus', show);
    inp.addEventListener('blur', function(){ setTimeout(hide, 120); });
    inp.addEventListener('keydown', function(e){
      if (dd.style.display === 'none') return;
      if (e.key === 'ArrowDown') { sel = (sel + 1) % cur.length; paint(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { sel = (sel - 1 + cur.length) % cur.length; paint(); e.preventDefault(); }
      else if (e.key === 'Enter' || e.key === 'Tab') { if (sel >= 0 && cur[sel]) { pick(cur[sel]); e.preventDefault(); } }
      else if (e.key === 'Escape') { hide(); e.preventDefault(); }
    });
  }
  function wrapSuggest(inp, opt){
    var l = inp.parentNode; if (!l || !l.parentNode) return;
    var w = el('div'); w.style.position = 'relative';
    l.parentNode.insertBefore(w, l); w.appendChild(l);
    inp.autocomplete = 'off'; suggestAttach(inp, w, opt);
  }
  var edits = {}, editing = false;
  try { edits = JSON.parse(localStorage.getItem('godeye_edits') || '{}'); } catch(e) {}
  function saveEdits(){ try { var k = Object.keys(edits); if (k.length > 60) k.slice(0, k.length - 60).forEach(function(x){ delete edits[x]; }); localStorage.setItem('godeye_edits', JSON.stringify(edits)); } catch(e) {} }
  function txtOf(rp){ return (rp && rp.brouillon_id && edits[rp.brouillon_id]) || (rp && rp.texte) || ''; }
  function envLocked(id){ var e = envois[id]; return !!(e && (e.st === 'programme' || e.st === 'envoye')); }
  // Clic direct sur le texte du brouillon pour le modifier ; enregistré dans Gmail quand on clique ailleurs.
  function editBox(box, stEl, getId, getT, setT){
    box.contentEditable = 'plaintext-only';
    box.spellcheck = true; box.lang = 'fr'; box.setAttribute('autocorrect', 'on');
    box.classList.add('editable');
    box.title = 'Clique pour modifier le texte';
    var orig = '';
    box.addEventListener('focus', function(){
      var id = getId();
      if (!id || envLocked(id)) { box.blur(); return; }
      editing = true; orig = getT(); stEl.textContent = ''; stEl.className = 'edst';
    });
    box.addEventListener('blur', function(){
      var id = getId();
      var nt = String(box.innerText || '').replace(/ /g, ' ').replace(/\r\n/g, '\n').replace(/\s+$/, '');
      if (!id || nt.trim() === orig.trim()) { editing = false; if (!nt.trim()) box.textContent = orig; return; }
      stEl.className = 'edst'; stEl.textContent = 'Enregistrement dans le brouillon…';
      envPost('modifier', {draft: id, old: orig, body: nt}).then(function(j){
        editing = false;
        if (j && j.ok) { edits[id] = nt; saveEdits(); setT(nt); stEl.className = 'edst ok'; stEl.textContent = '✓ Modifié à la main, enregistré dans le brouillon'; }
        else { stEl.className = 'edst ko'; stEl.textContent = 'Non enregistré' + (j && j.err ? ' (' + j.err + ')' : '') + '. Ton texte reste ici, le brouillon Gmail n’a pas changé.'; }
      }).catch(function(){ editing = false; stEl.className = 'edst ko'; stEl.textContent = 'Non enregistré (script injoignable ou à mettre à jour). Le brouillon Gmail n’a pas changé.'; });
    });
  }
  function envPull(){
    fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=envliste&t2=' + Date.now(), {credentials:'include'})
      .then(function(r){ return r.json(); })
      .then(function(j){
        if (!j || !j.ok || !j.items) return;
        var s = JSON.stringify(j.items);
        if (s === envSig) return;
        envSig = s; envois = j.items; render();
      })
      .catch(function(){});
  }
  function envInfoGet(id){
    var c = envInfo[id];
    if (envInfoBusy[id] || (c && (!c.err || Date.now() - c.at < 30000))) return;
    envInfoBusy[id] = true;
    fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=envinfo&d=' + encodeURIComponent(id), {credentials:'include'})
      .then(function(r){ return r.json(); })
      .then(function(j){ envInfo[id] = (j && j.ok) ? j : {err: (j && j.err) || ENV_VIEUX, at: Date.now()}; })
      .catch(function(){ envInfo[id] = {err: 'injoignable', at: Date.now()}; })
      .then(function(){ envInfoBusy[id] = false; render(); });
  }
  function envProg(id){ var e = id && envois[id]; return !!(e && e.st === 'programme'); }
  function envProgDe(grp){
    var r = null;
    (grp ? grp.all : []).forEach(function(x){ var p = reps[x.id]; var e = p && p.brouillon_id && envois[p.brouillon_id]; if (e && e.st === 'programme') r = e; });
    return r;
  }
  function envProgGroupe(grp){ return !!envProgDe(grp); }
  function envUiOf(id){ return envUi[id] || (envUi[id] = {open: false, d: '', h: '', busy: false, msg: ''}); }
  function envBar(box, id){
    box.textContent = '';
    if (!id) return;
    var ui = envUiOf(id), e = envois[id];
    if (!(e && e.st === 'envoye')) envInfoGet(id);
    var inf = envInfo[id];
    var dest = (inf && !inf.err && inf.to) ? inf.to : '';
    var redraw = function(){ envBar(box, id); };
    if (e && e.st === 'envoye') {
      var s0 = el('div', 'envstate ok'), t0 = el('div');
      t0.appendChild(el('div', null, '✓ Envoyé' + (e.at ? ' à ' + envHeure(new Date(e.at)) : '')));
      if (e.to || dest) t0.appendChild(el('div', 'small', 'À : ' + (e.to || dest)));
      s0.appendChild(t0); box.appendChild(s0);
      return;
    }
    if (e && e.st === 'programme') {
      var s1 = el('div', 'envstate'), t1 = el('div');
      s1.appendChild(el('span', 'envdot'));
      t1.appendChild(el('div', null, 'Part ' + envFmt(e.ts)));
      if (e.to) t1.appendChild(el('div', 'small', 'À : ' + e.to));
      s1.appendChild(t1); box.appendChild(s1);
    } else if (e && e.st === 'echec') {
      box.appendChild(el('div', 'envstate ko', 'L’envoi programmé n’est pas parti : ' + (e.err || 'erreur') + '. Le brouillon est toujours là.'));
    } else if (dest) {
      box.appendChild(el('div', 'muted', 'À : ' + dest + (inf.cc ? ' · Cc : ' + inf.cc : '')));
    } else if (inf && inf.err) {
      box.appendChild(el('div', 'muted', 'Destinataire non vérifiable (' + inf.err + ').'));
    }
    var prog = !!(e && e.st === 'programme');
    var row = el('div', 'envrow');
    var sb = el('button', 'btn send', prog ? '➤ Envoyer maintenant' : '➤ Envoyer'); sb.type = 'button'; sb.disabled = ui.busy;
    sb.addEventListener('click', function(){ envSend(id); });
    row.appendChild(sb);
    var pb = el('button', 'btn', prog ? '🕒 Changer l’heure' : '🕒 Programmer'); pb.type = 'button'; pb.disabled = ui.busy;
    pb.addEventListener('click', function(){
      ui.open = !ui.open;
      if (ui.open && !ui.d) { var c = envChips(new Date())[1]; ui.d = envDV(c.d); ui.h = envHV(c.d); }
      redraw();
    });
    row.appendChild(pb);
    if (prog) {
      var ab = el('button', 'btn undo', 'Annuler l’envoi'); ab.type = 'button'; ab.disabled = ui.busy;
      ab.addEventListener('click', function(){
        ui.busy = true; ui.msg = 'Annulation…'; redraw();
        envPost('annuler', {draft: id})
          .then(function(j){ if (!j || !j.ok) throw new Error((j && j.err) || ENV_VIEUX); delete envois[id]; ui.msg = ''; say('Envoi annulé, le brouillon est de nouveau modifiable'); })
          .catch(function(err){ ui.msg = 'Non annulé (' + (err && err.message || 'erreur') + ').'; })
          .then(function(){ ui.busy = false; envSig = ''; render(); envPull(); });
      });
      row.appendChild(ab);
    }
    box.appendChild(row);
    if (ui.open) {
      var pk = el('div', 'envbox');
      pk.appendChild(el('div', 'muted', 'Envoyer le'));
      var cw = el('div', 'envchips');
      envChips(new Date()).forEach(function(c){
        var cb = el('button', 'chip' + (ui.d === envDV(c.d) && ui.h === envHV(c.d) ? ' on' : ''), c.l); cb.type = 'button';
        cb.addEventListener('click', function(){ ui.d = envDV(c.d); ui.h = envHV(c.d); redraw(); });
        cw.appendChild(cb);
      });
      pk.appendChild(cw);
      var ir = el('div', 'envrow');
      var di = el('input', 'envin'); di.type = 'date'; di.value = ui.d; di.min = envDV(new Date());
      var hi = el('input', 'envin'); hi.type = 'time'; hi.value = ui.h;
      di.addEventListener('change', function(){ ui.d = di.value; redraw(); });
      hi.addEventListener('change', function(){ ui.h = hi.value; redraw(); });
      ir.appendChild(di); ir.appendChild(hi); pk.appendChild(ir);
      var ts = (ui.d && ui.h) ? new Date(ui.d + 'T' + ui.h).getTime() : NaN;
      var okTs = ts > Date.now() + 60000;
      pk.appendChild(el('div', 'muted', 'Le mail part tout seul à cette heure, même si ton Mac est éteint.'));
      var gr = el('div', 'envrow');
      var gb = el('button', 'btn send', okTs ? 'Programmer pour ' + envFmt(ts) : 'Choisis une date et une heure à venir'); gb.type = 'button'; gb.disabled = !okTs || ui.busy;
      gb.addEventListener('click', function(){ envProgrammer(id, ts); });
      gr.appendChild(gb);
      var cn = el('button', 'btn undo', 'Fermer'); cn.type = 'button';
      cn.addEventListener('click', function(){ ui.open = false; redraw(); });
      gr.appendChild(cn);
      pk.appendChild(gr); box.appendChild(pk);
    }
    if (ui.msg) box.appendChild(el('div', 'muted', ui.msg));
  }
  function envProgrammer(id, ts){
    var ui = envUiOf(id); if (ui.busy) return;
    ui.busy = true; ui.msg = 'Programmation…'; render();
    envPost('programmer', {draft: id, ts: ts})
      .then(function(j){
        if (!j || !j.ok) throw new Error((j && j.err) || ENV_VIEUX);
        envois[id] = {st: 'programme', ts: ts, to: j.to || ''};
        ui.open = false; ui.msg = '';
        say('Envoi programmé pour ' + envFmt(ts));
      })
      .catch(function(err){ ui.msg = 'Non programmé (' + (err && err.message || 'erreur') + ').'; })
      .then(function(){ ui.busy = false; envSig = ''; render(); envPull(); });
  }
  function envSend(id){
    var ui = envUiOf(id); if (ui.busy) return;
    ui.busy = true; ui.msg = 'Vérification du brouillon…'; render();
    fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=envinfo&d=' + encodeURIComponent(id) + '&t2=' + Date.now(), {credentials:'include'})
      .then(function(r){ return r.json(); })
      .then(function(j){
        if (!j || !j.ok) throw new Error((j && j.err) || ENV_VIEUX);
        if (!String(j.to || '').trim()) throw new Error('pas de destinataire');
        var q = (envProg(id) ? 'L’envoi programmé sera annulé et le mail part tout de suite.\n\n' : '')
          + 'Envoyer maintenant à ' + j.to + (j.cc ? ' (Cc : ' + j.cc + ')' : '') + ' ?\nObjet : ' + (j.subject || '(sans objet)') + (j.pj ? '\n' + j.pj + ' pièce(s) jointe(s)' : '');
        if (!window.confirm(q)) return null;
        ui.msg = 'Envoi…'; render();
        return envPost('envoyer', {draft: id}).then(function(r){
          if (!r || !r.ok) throw new Error((r && r.err) || ENV_VIEUX);
          envois[id] = {st: 'envoye', at: Date.now(), to: r.to || j.to};
          ui.open = false;
          say('Mail envoyé');
          setTimeout(autoTraite, 4000);
        });
      })
      .catch(function(err){ ui.msg = 'Non envoyé (' + (err && err.message || 'erreur') + ').'; })
      .then(function(){ if (ui.msg === 'Envoi…' || ui.msg === 'Vérification du brouillon…') ui.msg = ''; ui.busy = false; envSig = ''; render(); envPull(); });
  }
  var sentTxt = {}, replOld = {}, replBusy = {}, fresh = {};
  function supprBrouillon(id){
    if (!id) return;
    fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=remp', {method:'POST', credentials:'include', headers:{'Content-Type':'text/plain'}, body: JSON.stringify({ancien: id})})
      .then(function(r){ return r.json(); })
      .then(function(j){ say(j.ok ? 'Brouillon supprimé' : 'Brouillon non supprimé (' + (j.err || 'refus') + ')'); })
      .catch(function(){ say('Brouillon non supprimé (erreur)'); });
  }
  function startReplace(key, rp){
    var old = replOld[key]; delete replOld[key];
    if (!old || !rp || !rp.brouillon_id || rp.brouillon_id === old) return;
    replBusy[key] = true;
    fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=remp', {method:'POST', credentials:'include', headers:{'Content-Type':'text/plain'}, body: JSON.stringify({ancien: old, nouveau: rp.brouillon_id})})
      .then(function(r){ return r.json(); })
      .then(function(j){ say(j.ok ? 'Ancien brouillon remplacé' : 'Ancien brouillon conservé (' + (j.err || 'refus') + ') : supprime-le à la main'); })
      .catch(function(){ say('Ancien brouillon conservé (erreur) : supprime-le à la main'); })
      .then(function(){ replBusy[key] = false; render(); });
  }
  function sendConsigne(f, txt){
    pending[f.id] = Math.floor(Date.now() / 1000) - 2;
    pjArm(f.id);
    say('Consigne envoyée à God Eye…');
    localPost('/reponse', {thread: f.thread || f.id, key: f.id, texte: txt})
      .then(function(r){ if (!r.ok) throw new Error('refus'); say('God Eye rédige la réponse (environ 1 minute)…'); })
      .catch(function(){ delete pending[f.id]; say('Récepteur local injoignable : God Eye est-il lancé sur le Mac ?'); render(); });
    render();
  }
  function refreshNow(){
    var b = document.getElementById('refresh');
    b.classList.add('spin');
    say('Recherche des nouveaux mails…');
    fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=scan', {method:'POST', credentials:'include'})
      .catch(function(){})
      .then(function(){ return localPost('/maj'); })
      .then(function(){ say('Analyse en cours (environ 1 minute)…'); })
      .catch(function(){ say('Récepteur local injoignable : God Eye est-il lancé sur le Mac ?'); })
      .then(function(){ setTimeout(function(){ b.classList.remove('spin'); }, 4000); refresh(); });
  }
  var GMAIL = 'https://mail.google.com/mail/?authuser=' + encodeURIComponent(GE_CONFIG.MAIL) + '#all/';

  window.godeyeAdd = function(f){
    if (!f || !f.id) return;
    fiches[f.id] = f;
    render();
  };

  function parseRdv(txt, now){
    var t = ' ' + (txt || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'') + ' ';
    var emails = (txt || '').match(/[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+/gi) || [];
    t = t.replace(/[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+/g,' ');
    var dur = 60, m;
    if ((m = t.match(/(?:pendant|duree|pour)\s*(\d{1,2})\s*h\s*(\d{2})?/))) { dur = parseInt(m[1],10)*60 + (m[2] ? parseInt(m[2],10) : 0); t = t.replace(m[0],' '); }
    else if ((m = t.match(/(\d{1,3})\s*(?:min|mn)\b/))) { dur = parseInt(m[1],10); t = t.replace(m[0],' '); }
    var hh = null, mi = 0;
    if ((m = t.match(/(\d{1,2})\s*(?:h|:)\s*(\d{2})?/))) { hh = parseInt(m[1],10); mi = m[2] ? parseInt(m[2],10) : 0; t = t.replace(m[0],' '); }
    var day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var dt = null;
    var mois = ['janvier','fevrier','mars','avril','mai','juin','juillet','aout','septembre','octobre','novembre','decembre'];
    var jours = ['dimanche','lundi','mardi','mercredi','jeudi','vendredi','samedi'];
    if ((m = t.match(/(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?/))) {
      var y = m[3] ? parseInt(m[3],10) : day0.getFullYear(); if (y < 100) y += 2000;
      dt = new Date(y, parseInt(m[2],10)-1, parseInt(m[1],10));
      if (!m[3] && dt < day0) dt = new Date(y+1, dt.getMonth(), dt.getDate());
    } else if ((m = t.match(new RegExp('(\\d{1,2})(?:er)?\\s*(' + mois.join('|') + ')')))) {
      dt = new Date(day0.getFullYear(), mois.indexOf(m[2]), parseInt(m[1],10));
      if (dt < day0) dt = new Date(day0.getFullYear()+1, dt.getMonth(), dt.getDate());
    } else if (/apres-?\s*demain/.test(t)) { dt = new Date(day0.getTime() + 2*86400000); }
    else if (/demain/.test(t)) { dt = new Date(day0.getFullYear(), day0.getMonth(), day0.getDate()+1); }
    else if (/aujourd/.test(t)) { dt = day0; }
    else if ((m = t.match(new RegExp('(' + jours.join('|') + ')\\s*(\\d{1,2})?\\b')))) {
      var wd = jours.indexOf(m[1]);
      if (m[2]) {
        var dn = parseInt(m[2],10), k;
        for (k = 0; k < 14; k++) { var c = new Date(day0.getFullYear(), day0.getMonth(), day0.getDate()+k); if (c.getDate() === dn) { dt = c; break; } }
        if (!dt) dt = null;
      } else {
        var add = (wd - day0.getDay() + 7) % 7; if (add === 0) add = 7;
        dt = new Date(day0.getFullYear(), day0.getMonth(), day0.getDate()+add);
      }
    }
    return {date: dt, h: hh, mi: mi, dur: dur, emails: emails};
  }

  function el(tag, cls, text){
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = String(text);
    return e;
  }
  function fmt(iso){
    var d = new Date(iso);
    if (isNaN(d)) return '';
    return d.toLocaleString('fr-FR', {day:'numeric', month:'short', hour:'2-digit', minute:'2-digit'});
  }
  function nomDe(f){ var x = (f.expediteur || ''); var n = x.replace(/<.*$/,'').replace(/\(.*$/,'').replace(/["]/g,'').trim(); return n || ((x.match(/[a-z0-9._+-]+@[a-z0-9.-]+/i) || [''])[0]) || x; }
  function adrDe(f){ return ((f.expediteur || '').match(/[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+/i) || [''])[0]; }
  function lvl(f){
    var n = f.urgence && f.urgence.niveau;
    return (n === 'haute' || n === 'moyenne' || n === 'basse') ? n : 'moyenne';
  }
  function sorted(){
    return Object.keys(fiches).map(function(k){return fiches[k];}).sort(function(a,b){
      return new Date(b.date) - new Date(a.date);
    });
  }
  function normk(f){ var m = ((f.expediteur||'').toLowerCase().match(/[a-z0-9._+-]+@[a-z0-9.-]+/)||[''])[0]; var s = (f.objet||'').toLowerCase().replace(/^(\s*(re|tr|fwd?|rép)\s*:\s*)+/g,'').replace(/\(\s*\d+\s*\)/g,' ').replace(/\bpi[èe]ces?\b/g,'documents').replace(/\bdocuments?\b/g,'documents').replace(/\battendu(e|s|es)?\b/g,'attendu').replace(/[^a-z0-9àâçéèêëîïôûùü]+/g,' ').trim(); return s ? m + '|' + s : ''; }
  function tkey(f){ var n = normk(f); if(!n) return f.thread || f.id; var best = f; Object.keys(fiches).forEach(function(k){ var g = fiches[k]; if(normk(g) === n && new Date(g.date) < new Date(best.date)) best = g; }); return best.thread || best.id; }

  function groups(){
    var m = {};
    sorted().forEach(function(f){ (m[tkey(f)] = m[tkey(f)] || []).push(f); });
    return Object.keys(m).map(function(k){ return {key:k, main:m[k][0], all:m[k]}; })
      .sort(function(a,b){ return new Date(b.main.date) - new Date(a.main.date); });
  }
  function groupOf(k){
    return groups().filter(function(g){ return g.key === k; })[0] || null;
  }
  function markSeen(id){
    seen[id] = 1;
    try { localStorage.setItem('godeye_seen', JSON.stringify(seen)); } catch(e) {}
  }

  function renderList(){
    var list = document.getElementById('list');
    list.textContent = '';
    var all = groups();
    var nTodo = all.filter(function(g){return !done[g.main.id];}).length;
    var nDone = all.length - nTodo;
    document.getElementById('count').textContent = nTodo + ' à traiter';
    var tabs = el('div','tabs');
    [['todo','À traiter (' + nTodo + ')'],['done','Traités (' + nDone + ')']].forEach(function(t){
      var tb = el('button','tab' + (filter === t[0] ? ' on' : ''), t[1]);
      tb.type = 'button';
      tb.addEventListener('click', function(){ filter = t[0]; render(); });
      tabs.appendChild(tb);
    });
    list.appendChild(tabs);
    var arr = all.filter(function(g){ return filter === 'done' ? !!done[g.main.id] : !done[g.main.id]; });
    if (!arr.length){
      list.appendChild(el('div','empty', filter === 'done' ? 'Aucun dossier traité pour l’instant.' : (all.length ? 'Tout est traité, bravo.' : 'Les nouveaux mails apparaîtront ici dans les 10 minutes qui suivent leur arrivée.')));
      return;
    }
    arr.forEach(function(g){
      var f = g.main;
      var b = el('button','card u-' + lvl(f) + (selected === g.key ? ' on' : '') + (done[f.id] ? ' isdone' : ''));
      b.type = 'button';
      var r1 = el('div','row sp');
      var left = el('div','row');
      
      left.appendChild(el('span','bien', f.bien || f.objet || 'Mail'));
      r1.appendChild(left);
      r1.appendChild(el('span','time', fmt(f.date)));
      b.appendChild(r1);
      var ex = el('div','exp', nomDe(f)); ex.title = f.expediteur || ''; b.appendChild(ex);
      b.appendChild(el('div','obj', f.objet || ''));
      var r3 = el('div','row');
      if (done[f.id]) r3.appendChild(el('span','ok','Traité'));
      else if (!seen[f.id]) r3.appendChild(el('span','new','Nouvelle'));
      if (f.brouillon_cree) r3.appendChild(el('span','draft','Brouillon prêt'));
      if (relances && relances[f.id]) r3.appendChild(el('span','draft','Relance'));
      var epg = envProgDe(g);
      if (epg) r3.appendChild(el('span','draft sched','Programmé ' + envCourt(epg.ts)));
      if (g.all.length > 1) r3.appendChild(el('span','nb', g.all.length + ' mails'));
      if (r3.childNodes.length) b.appendChild(r3);
      b.addEventListener('click', function(){ select(g.key); });
      list.appendChild(b);
    });
  }

  function section(cls, title, items){
    if (!items || !items.length) return null;
    var s = el('section','sec');
    s.appendChild(el('h3', cls, title));
    var u = el('ul');
    items.forEach(function(t){ u.appendChild(el('li', null, t)); });
    s.appendChild(u);
    return s;
  }

  var pdvRes = {};
  var PDV_URL = 'https://www.pointdevente.fr/middle/produit.list';
  var PDV_TX = [['cession de bail', 1], ['fonds de commerce', 6], ['location pure', 2], ['droit d\'entree', 3], ['murs libres', 4], ['murs occupes', 5]];
  var PDV_TYPE = [['bureau', 1], ['entrepot', 2], ['cour', 3], ['commerce', 4]];
  function pdvNz(x){ return String(x || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function pdvSearch(f){
    var rc = f.recherche;
    var st = pdvRes[f.id] = {s: 'loading', items: [], seen: 0};
    var tp = 4; var t0 = pdvNz(rc.type_bien);
    for (var i = 0; i < PDV_TYPE.length; i++) { if (t0 && t0.indexOf(PDV_TYPE[i][0]) >= 0) { tp = PDV_TYPE[i][1]; break; } }
    var tx = [];
    (rc.transactions || []).forEach(function(x){ var n = pdvNz(x); PDV_TX.forEach(function(p){ if (n.indexOf(p[0]) >= 0 && tx.indexOf(p[1]) < 0) tx.push(p[1]); }); });
    var num = function(v){ var n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isFinite(n) && n > 0 ? String(Math.round(n)) : ''; };
    var cps = (rc.codes_postaux || []).map(String), deps = (rc.departements || []).map(String);
    var rues = (rc.rues || []);
    var vls0 = (rc.villes_quartiers || []).map(function(v){ return pdvAl(v); });
    var useDeps = deps.length && !cps.length && !vls0.length;
    var zoneOk = function(adr){
      var na = ' ' + pdvAl(adr) + ' ';
      if (rues.length && !rues.some(function(r){ return na.indexOf(' ' + r + ' ') >= 0; })) return false;
      if (!cps.length && !deps.length && !vls0.length) return true;
      var m = (adr || '').match(/\b(\d{5})\b/);
      if (m && cps.indexOf(m[1]) >= 0) return true;
      if (useDeps && m && deps.some(function(d){ return m[1].indexOf(d) === 0; })) return true;
      return vls0.some(function(v){
        var n2 = (v === 'colombes') ? na.replace(' bois colombes ', ' ').replace(' garenne colombes ', ' ') : na;
        return v && n2.indexOf(' ' + v) >= 0;
      });
    };
    var page = function(off){
      var p = new URLSearchParams();
      p.set('full', '1'); p.set('search', '1'); p.set('search_type', '1'); p.set('order_by_date', 'created_on.DESC'); p.set('offset', String(off));
      p.set('recherche[produit_type]', String(tp));
      tx.forEach(function(c){ p.append('recherche[subtransaction][]', String(c)); });
      p.append('recherche[status][]', '10');
      var m = {surface_total_min: num(rc.surface_min), surface_total_max: num(rc.surface_max), rent_monthly_display_min: num(rc.loyer_min_mensuel), rent_monthly_display_max: num(rc.loyer_max_mensuel), price_selling_min: num(rc.prix_min), price_selling_max: num(rc.prix_max)};
      Object.keys(m).forEach(function(k){ if (m[k]) p.set('recherche[' + k + ']', m[k]); });
      return fetch(PDV_URL, {method: 'POST', credentials: 'include', headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'}, body: p.toString()})
        .then(function(r){ if (!r.ok) throw new Error('http'); return r.text(); });
    };
    var ids = {};
    var maxPages = (rues.length || cps.length || deps.length || (rc.villes_quartiers || []).length) ? 16 : 8;
    var step = function(off, n){
      page(off).then(function(h){
        var d = new DOMParser().parseFromString('<table><tbody>' + h + '</tbody></table>', 'text/html');
        var links = [].slice.call(d.querySelectorAll('a.produit-link'));
        if (!links.length && off === 0) {
          st.s = 'err'; st.msg = /type=["']password|connexion|identifiant/i.test(h) ? 'Connecte-toi à PDV Connect dans Chrome, puis relance.' : 'Aucun résultat lisible de PDV Connect.';
          render(); return;
        }
        var fresh2 = 0;
        links.forEach(function(a){
          var href = a.getAttribute('href') || ''; var id = (href.match(/id\/(\d+)/) || [])[1];
          if (!id || ids[id]) return;
          ids[id] = 1; fresh2++; st.seen++;
          var tr = a.closest('tr'); var c = tr ? [].slice.call(tr.children).map(function(x){ return x.textContent.replace(/\s+/g, ' ').trim(); }) : [];
          var tx2 = function(e){ return e ? e.textContent.replace(/\s+/g, ' ').trim() : ''; };
          var adr = tx2(a.querySelector('.adresse')); var cons = tx2(a.querySelector('em'));
          if (GE_CONFIG.PDV_EXCLURE && cons.toLowerCase().indexOf(String(GE_CONFIG.PDV_EXCLURE).toLowerCase()) >= 0) return;
          if (!zoneOk(adr)) return;
          if (st.items.length < (rc.max || 12)) st.items.push({id: id, adr: adr, ref: tx2(a.querySelector('.reference')).replace(/\s*\(VL.*$/, ''), cons: cons, trans: c[1] || '', surf: (c[2] || '').replace(/\s*S\/sol.*$/, ''), loyer: c[3] || '', prix: c[5] || ''});
        });
        if (st.items.length >= (rc.max || 12) || !fresh2 || links.length < 50 || n >= maxPages - 1) { st.s = 'ok'; render(); return; }
        step(off + 50, n + 1);
      }).catch(function(){ st.s = 'err'; st.msg = 'PDV Connect injoignable depuis l’extension (session expirée ou accès non autorisé).'; render(); });
    };
    step(0, 0);
  }
  function pdvSection(f){
    var rc = f.recherche; if (!rc || typeof rc !== 'object') return null;
    var sec = el('section', 'sec');
    sec.appendChild(el('h3', 't', 'Recherche du client'));
    var bits = [];
    if (rc.type_bien) bits.push(rc.type_bien);
    if ((rc.transactions || []).length) bits.push(rc.transactions.join(' / '));
    if (rc.surface_min || rc.surface_max) bits.push((rc.surface_min || '') + (rc.surface_max ? '-' + rc.surface_max : '+') + ' m²');
    if (rc.loyer_max_mensuel) bits.push('loyer max ' + rc.loyer_max_mensuel + ' €/mois');
    if (rc.prix_max) bits.push('prix max ' + rc.prix_max + ' €');
    var zn = (rc.codes_postaux || []).concat(rc.departements || []).concat(rc.villes_quartiers || []);
    if (zn.length) bits.push(zn.join(', '));
    if (rc.activite) bits.push(rc.activite);
    if (rc.notes) bits.push(rc.notes);
    sec.appendChild(el('div', null, bits.join(' · ') || 'Critères non précisés'));
    var st = pdvRes[f.id];
    if (!st) { st = null; pdvSearch(f); st = pdvRes[f.id]; }
    sec.appendChild(el('h3', 't', 'Biens PDV correspondants'));
    if (st.s === 'loading') sec.appendChild(el('div', 'muted', 'Recherche dans PDV Connect…'));
    else if (st.s === 'err') sec.appendChild(el('div', 'muted', st.msg || 'Recherche impossible.'));
    else if (!st.items.length) sec.appendChild(el('div', 'muted', 'Aucun bien actif ne correspond (' + st.seen + ' biens passés en revue).'));
    else {
      st.items.forEach(function(it){
        var a = el('a', 'card'); a.href = 'https://www.pointdevente.fr/middle/produit.fiche/-/id/' + it.id; a.target = '_blank'; a.rel = 'noopener noreferrer'; a.style.marginBottom = '8px';
        a.appendChild(el('span', 'bien', it.adr));
        a.appendChild(el('span', 'obj', [it.trans, it.surf, it.loyer ? it.loyer + ' €/mois' : '', it.prix && it.prix !== '0 €' ? it.prix : ''].filter(Boolean).join(' · ')));
        a.appendChild(el('span', 'obj', it.ref + (it.cons ? ' · ' + it.cons : '')));
        sec.appendChild(a);
      });
      sec.appendChild(el('div', 'muted', 'Biens actifs uniquement.' + (GE_CONFIG.PDV_EXCLURE ? ' Les biens de ' + GE_CONFIG.PDV_EXCLURE + ' sont exclus.' : '')));
    }
    var rb = el('button', 'btn undo', 'Relancer la recherche'); rb.type = 'button'; rb.style.marginTop = '8px';
    rb.addEventListener('click', function(){ pdvSearch(f); render(); });
    sec.appendChild(rb);
    return sec;
  }
  var pdvC = {};
  var CONTACT_TYPES = ['Acquéreur', 'Propriétaire', 'Cédant', 'Confrère'];
  function ctNom(f){
    var n = (f.expediteur || '').replace(/<.*$/, '').replace(/\(.*$/, '').replace(/["']/g, '').replace(/\s+/g, ' ').trim();
    if (!n || /@/.test(n)) return {nom: '', prenom: ''};
    var tk = n.split(' ');
    if (tk.length === 1) return {nom: tk[0], prenom: ''};
    var up = tk.filter(function(w){ return w.length > 1 && w === w.toUpperCase() && /[A-ZÀ-Ý]/.test(w); });
    if (up.length && up.length < tk.length) return {nom: up.join(' '), prenom: tk.filter(function(w){ return up.indexOf(w) < 0; }).join(' ')};
    return {prenom: tk[0], nom: tk.slice(1).join(' ')};
  }
  function ctCiv(f){
    var s = ' ' + (f.expediteur || '') + ' ' + (f.objet || '') + ' ';
    if (/\b(mme|madame)\b/i.test(s)) return 'Mme';
    if (/\b(mlle|mademoiselle)\b/i.test(s)) return 'Mlle';
    if (/\b(m\.|monsieur)\s/i.test(s)) return 'M.';
    return '';
  }
  function ctTel(f){
    var tel = f.telephone_client || '';
    if (!tel) {
      var cand = JSON.stringify(f).match(/(?:\+33|0033|0)[\s.]?[1-9](?:[\s.-]?\d{2}){4}/g) || [];
      for (var ci = 0; ci < cand.length; ci++) { var dg = cand[ci].replace(/\D/g, '').replace(/^(33|0033)/, '0'); if (GE_CONFIG.TEL_EXCLUS.indexOf(dg) < 0) { tel = cand[ci]; break; } }
    }
    return tel;
  }
  function ctFind(email){
    var p = new URLSearchParams();
    p.set('search', '1'); p.set('offset', '0'); p.set('email', email);
    for (var i = 1; i <= 10; i++) p.append('type[]', String(i));
    return fetch('https://www.pointdevente.fr/middle/contact.list', {method: 'POST', credentials: 'include', headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'}, body: p.toString()})
      .then(function(r){ if (!r.ok) throw new Error('http'); return r.text(); })
      .then(function(h){
        if (/type=["']password/i.test(h)) throw new Error('login');
        var d = new DOMParser().parseFromString('<table><tbody>' + h + '</tbody></table>', 'text/html');
        return [].slice.call(d.querySelectorAll('tr')).filter(function(t){ return t.children.length >= 8; }).slice(0, 5).map(function(t){
          var c = [].slice.call(t.children).map(function(x){ return x.textContent.replace(/\s+/g, ' ').trim(); });
          return {nom: c[0], date: c[1], type: c[2]};
        });
      });
  }
  function ctFill(d){
    var q = function(sfx){ return document.querySelector('input[name$="' + sfx + '"]'); };
    var set = function(e, v){ if (!e || !v) return; e.focus(); e.value = v; e.dispatchEvent(new Event('input', {bubbles: true})); e.dispatchEvent(new Event('change', {bubbles: true})); };
    var lab = function(e){ var l = e.id && document.querySelector('label[for="' + e.id + '"]'); return (l ? l.textContent : (e.parentElement && e.parentElement.textContent) || '').replace(/\s+/g, ' ').trim(); };
    set(q('[last_name]'), d.nom); set(q('[first_name]'), d.prenom); set(q('[phone]'), d.tel); set(q('[email]'), d.email);
    if (d.civ) { var r = [].slice.call(document.querySelectorAll('input[name$="[civility]"]')).filter(function(x){ return lab(x) === d.civ; })[0]; if (r) r.click(); }
    [].slice.call(document.querySelectorAll('input[type=checkbox][name$="[type][]"]')).forEach(function(c){ var want = lab(c) === d.type; if (c.checked !== want) c.click(); });
    var nzp = function(x){ return String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim(); };
    var got = '';
    var sel = document.querySelector('select[name$="[activites][1]"]');
    if (sel && d.acts && d.acts.length) {
      var w = nzp(d.acts[0]).slice(0, 12);
      var op = [].slice.call(sel.options).filter(function(o){ return nzp(o.textContent).slice(0, 12) === w; })[0];
      if (op) { sel.value = op.value; sel.dispatchEvent(new Event('change', {bubbles: true})); got = op.textContent.trim(); }
    }
    return JSON.stringify({act: got});
  }
  var ACT_MAP = [
    ['fitness|salle de sport|salle de gym|\\bgym\\b|crossfit|club de sport', 'Salle de sport'], ['pilates', 'Pilates'], ['coffee', 'Coffee Shop'],
    ['fast.?food|restauration rapide|snacking|\\bsnack', 'Fast food Cdc'], ['brasserie', 'Bar Brasserie'], ['restaurant|restauration', 'Restaurant'], ['\\bbar\\b', 'Bar'],
    ['hotel', 'Hôtel'], ['boulangerie', 'Boulangerie'], ['patisserie|salon de the', 'Pâtisserie / Salon de thé'], ['boucherie|charcuterie', 'Boucherie / Charcuterie'],
    ['fromagerie', 'Fromagerie'], ['poissonnerie', 'Poissonnerie'], ['primeur|fruits et legumes', 'Fruits et légumes'], ['epicerie fine', 'Epicerie fine'],
    ['alimentation|epicerie|superette', 'Alimentation générale'], ['\\bcave\\b|caviste', 'Cave à vin / bière'], ['supermarche', 'Supermarché'], ['pharmacie', 'Pharmacie'],
    ['optique|opticien', 'Optique'], ['coiffeur|coiffure|barbier', 'Coiffeur / Barbier'], ['centre de beaute', 'Centre de Beauté (<100m²)'],
    ['institut de beaute|esthetic|\\bspa\\b', 'Institut de beauté (> 100m²)'], ['massage', 'Soins du corps (massage)'], ['parfumerie', 'Parfumerie'], ['cosmetique', 'Cosmétique'],
    ['coworking', 'Coworking'], ['bureaux?', 'Bureaux'], ['banque', 'Banque'], ['agence immobiliere', 'Agence immobiiere'], ['agence de voyage', 'Agence de voyage'],
    ['librairie', 'Librairie'], ['pret.?a.?porter|vetement', 'Prêt à porter'], ['chaussure', 'Chaussure'], ['bijou', 'Bijouterie'], ['fleuriste', 'Fleuriste'],
    ['laverie', 'Laverie'], ['pressing', 'Pressing'], ['creche', 'Crèche'], ['assureur|assurance', 'Assureur'], ['telephon|informatique', 'Téléphonie / Informatique / Imprimerie'],
    ['garage|concession', 'Garage / Concessionnaire'], ['auto.?ecole', 'Auto-école']
  ];
  function ctActs(f){
    var rc = f.recherche || {};
    var t = pdvNz([rc.activite, f.bien, f.resume_bien].filter(Boolean).join(' . '));
    var hits = [];
    ACT_MAP.forEach(function(a){ var m = new RegExp(a[0]).exec(t); if (m) hits.push({i: m.index, l: a[1]}); });
    hits.sort(function(x, y){ return x.i - y.i; });
    var out = []; hits.forEach(function(h){ if (out.indexOf(h.l) < 0) out.push(h.l); });
    return out;
  }
  function ctOpen(f, type, st){
    var nm = ctNom(f);
    var acts = ctActs(f);
    var data = {nom: nm.nom, prenom: nm.prenom, email: adrDe(f), tel: ctTel(f), civ: ctCiv(f), type: type, acts: acts};
    if (!(window.chrome && chrome.tabs && chrome.scripting)) { st.msg = 'Recharge l’extension dans chrome://extensions et accepte la nouvelle autorisation.'; render(); return; }
    chrome.tabs.create({url: 'https://www.pointdevente.fr/middle/acquereur.edit'}, function(tab){
      if (!tab) { st.msg = 'Impossible d’ouvrir PDV Connect.'; render(); return; }
      var done = false;
      var go = function(){
        if (done) return; done = true;
        chrome.scripting.executeScript({target: {tabId: tab.id}, func: ctFill, args: [data]}, function(res){
          if (chrome.runtime.lastError) { st.msg = 'Formulaire ouvert mais non rempli, remplis-le à la main.'; render(); return; }
          var info = {}; try { info = JSON.parse((res && res[0] && res[0].result) || '{}'); } catch (e) {}
          var m = 'Formulaire PDV ouvert et prérempli. Vérifie puis enregistre toi-même.';
          if (acts.length) {
            if (info.act) m += ' Activité renseignée : ' + info.act + '.' + (acts.length > 1 ? ' À ajouter à la main : ' + acts.slice(1).join(', ') + '.' : '');
            else m += ' Activité non trouvée dans la liste PDV (' + acts.join(', ') + ').';
          }
          st.msg = m; render();
        });
      };
      var lis = function(id, info){ if (id === tab.id && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(lis); go(); } };
      chrome.tabs.onUpdated.addListener(lis);
      setTimeout(function(){ chrome.tabs.onUpdated.removeListener(lis); go(); }, 8000);
    });
  }
  function contactSection(f){
    var em = adrDe(f);
    var st = pdvC[f.id] || (pdvC[f.id] = {type: f.recherche ? 'Acquéreur' : 'Propriétaire', msg: '', found: null});
    var sec = el('section', 'sec');
    sec.appendChild(el('h3', 't', 'Contact PDV'));
    var nm = ctNom(f);
    sec.appendChild(el('div', 'muted', [ctCiv(f), nm.prenom, nm.nom].filter(Boolean).join(' ') + (em ? ' · ' + em : '') + (ctTel(f) ? ' · ' + ctTel(f) : '') + (ctActs(f).length ? ' · ' + ctActs(f).join(', ') : '')));
    var row = el('div', 'pjrow'); row.style.marginTop = '8px';
    var sel = el('select', 'rdvi'); sel.style.width = 'auto';
    CONTACT_TYPES.forEach(function(t){ var o = document.createElement('option'); o.value = t; o.textContent = t; if (t === st.type) o.selected = true; sel.appendChild(o); });
    sel.addEventListener('change', function(){ st.type = sel.value; });
    row.appendChild(sel);
    var bt = el('button', 'btn send', 'Créer le contact PDV'); bt.type = 'button';
    if (st.busy) { bt.disabled = true; bt.classList.add('busy'); bt.textContent = 'Vérification…'; }
    bt.addEventListener('click', function(){
      if (!em) { st.msg = 'Pas d’adresse mail pour cette fiche.'; render(); return; }
      st.busy = true; st.msg = ''; st.found = null; render();
      ctFind(em).then(function(rows){
        st.busy = false;
        if (rows.length) { st.found = rows; st.msg = ''; render(); }
        else { render(); ctOpen(f, st.type, st); }
      }).catch(function(e){
        st.busy = false;
        st.msg = (e && e.message === 'login') ? 'Connecte-toi à PDV Connect dans Chrome, puis relance.' : 'Vérification des doublons impossible. Ouverture du formulaire sans contrôle.';
        render(); ctOpen(f, st.type, st);
      });
    });
    row.appendChild(bt); sec.appendChild(row);
    if (st.found && st.found.length) {
      sec.appendChild(el('div', 'muted', 'Déjà dans PDV : ' + st.found.map(function(r){ return [r.nom, r.type, r.date].filter(Boolean).join(' · '); }).join(' | ')));
      var fo = el('button', 'btn undo', 'Créer quand même'); fo.type = 'button'; fo.style.marginTop = '6px';
      fo.addEventListener('click', function(){ st.found = null; ctOpen(f, st.type, st); });
      sec.appendChild(fo);
    }
    if (st.msg) sec.appendChild(el('div', 'muted', st.msg));
    return sec;
  }
  function renderDetail(){
    var d = document.getElementById('detail');
    var hadFocus = document.activeElement && document.activeElement.id === 'consigne';
    d.textContent = '';
    var grp = selected && groupOf(selected);
    var f = grp && grp.main;
    if (!f){
      if (groups().length) d.appendChild(el('div','empty','Choisis une fiche dans la liste.'));
      return;
    }
    var back = el('button','back','← Retour');
    back.type = 'button';
    back.addEventListener('click', function(){ selected = null; document.body.classList.remove('sel'); render(); });
    d.appendChild(back);

    var h = el('div','dh');
    h.appendChild(el('div','kicker', f.bien || ''));
    h.appendChild(el('div','who', nomDe(f)));
    if (adrDe(f)) h.appendChild(el('div','addr', adrDe(f)));
    h.appendChild(el('div','obj', f.objet || ''));
    h.appendChild(el('div','chip ' + lvl(f), (f.urgence && f.urgence.texte) || 'Urgence à évaluer'));
    d.appendChild(h);

    var s;
    if ((s = section('t','Ce que le mail demande', f.demandes))) d.appendChild(s);
    if ((s = pdvSection(f))) d.appendChild(s);

    if (f.chiffres && f.chiffres.length){
      var sc = el('section','sec');
      sc.appendChild(el('h3','t','Chiffres'));
      var g = el('div','grid');
      f.chiffres.forEach(function(c){
        var x = el('div','fig');
        x.appendChild(el('span',null,c.label));
        x.appendChild(el('b',null,c.valeur));
        g.appendChild(x);
      });
      sc.appendChild(g);
      if (f.resume_bien) sc.appendChild(el('div','muted', f.resume_bien));
      d.appendChild(sc);
    } else if (f.resume_bien){
      var sb = el('section','sec');
      sb.appendChild(el('h3','t','Le bien'));
      sb.appendChild(el('div',null,f.resume_bien));
      d.appendChild(sb);
    }

    if ((s = section('a','À vérifier', f.a_verifier))) d.appendChild(s);
    if ((s = section('m','Pièces manquantes', f.pieces_manquantes))) d.appendChild(s);

    if (f.reponse){
      var sr = el('section','sec');
      sr.appendChild(el('h3','t','Réponse'));
      sr.appendChild(el('div',null,f.reponse));
      d.appendChild(sr);
    }

    var rdvBox = null, rdvBtn = null;
    (function(){
      var rv = f.rdv || {};
      var q = rdvs[f.id];
      if (!q) {
        var ok = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(rv.debut || '');
        q = rdvs[f.id] = { txt: ok ? rv.debut.slice(8,10) + '/' + rv.debut.slice(5,7) + ' ' + rv.debut.slice(11,13) + 'h' + rv.debut.slice(14,16) : '' };
      }
      var em = ((f.expediteur || '').match(/[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+/i) || [''])[0];
      var bien = (f.bien && f.bien !== 'non communiqué') ? f.bien : '';
      var sec = el('div','rdvbox');
      var ta2 = el('textarea','consigne');
      ta2.rows = 2;
      ta2.placeholder = 'Ex : mardi 10 à 15h  (ajoute « 30 min » ou « pendant 1h30 » pour la durée)';
      ta2.value = q.txt;
      sec.appendChild(ta2);
      var info = el('div','muted','');
      var inv = el('input','rdvi'); inv.type = 'text'; inv.placeholder = 'Inviter une autre personne (adresse mail)'; inv.value = q.inv || '';
      inv.addEventListener('input', function(){ q.inv = inv.value; });
      var bt = el('button','btn','Ouvrir dans Google Agenda');
      bt.type = 'button';
      var calc = function(){
        var r = parseRdv(ta2.value, new Date());
        if (!r.date || r.h === null || r.h > 23 || r.mi > 59) return null;
        r.st = new Date(r.date.getFullYear(), r.date.getMonth(), r.date.getDate(), r.h, r.mi);
        r.en = new Date(r.st.getTime() + r.dur * 60000);
        return r;
      };
      var maj = function(){
        q.txt = ta2.value;
        var r = calc();
        if (!r) { info.textContent = ta2.value.trim() ? 'Il me faut une date et une heure (ex : mardi 10 à 15h).' : ''; return; }
        info.textContent = '→ ' + r.st.toLocaleDateString('fr-FR', {weekday:'long', day:'numeric', month:'long'}) + ' à ' + r.st.getHours() + 'h' + (r.st.getMinutes() < 10 ? '0' : '') + r.st.getMinutes() + ', ' + r.dur + ' min';
      };
      ta2.addEventListener('input', maj);
      bt.addEventListener('click', function(){
        var r = calc();
        if (!r) { maj(); if (!info.textContent) info.textContent = 'Écris la date et l’heure.'; return; }
        var pad = function(n){ return (n < 10 ? '0' : '') + n; };
        var cp = function(d){ return d.getFullYear() + pad(d.getMonth()+1) + pad(d.getDate()) + 'T' + pad(d.getHours()) + pad(d.getMinutes()) + '00'; };
        var gs = r.emails.slice(); if (em && !moi(em)) gs.push(em);
        (inv.value.match(/[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+/gi) || []).forEach(function(m){ gs.push(m); });
        gs = gs.filter(function(m, k){ return !moi(m) && gs.indexOf(m) === k; });
        var nz = function(x){ return (x || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,''); };
        var ctx = nz(ta2.value) + ' | ' + nz(f.objet) + ' ' + nz((f.demandes || []).join(' ')) + ' ' + nz(f.reponse);
        var types = [['visite','Visite'],['appel|telephon|rappel|call','Appel'],['signature|signer','Signature'],['estimation|avis de valeur|valorisation','Estimation'],['reunion|point ','Réunion'],['visio|teams|zoom|meet','Visio']];
        var typ = 'RDV';
        var tyTxt = nz(ta2.value);
        for (var ti = 0; ti < types.length; ti++) { if (new RegExp(types[ti][0]).test(tyTxt)) { typ = types[ti][1]; break; } }
        if (typ === 'RDV') { for (var tj = 0; tj < types.length; tj++) { if (new RegExp(types[tj][0]).test(ctx)) { typ = types[tj][1]; break; } } }
        var titre = rv.titre || (typ + ' ' + (bien || f.objet || '')).trim();
        var tel = f.telephone_client || '';
        if (!tel) {
          var cand = JSON.stringify(f).match(/(?:\+33|0033|0)[\s.]?[1-9](?:[\s.-]?\d{2}){4}/g) || [];
          for (var ci = 0; ci < cand.length; ci++) { var dg = cand[ci].replace(/\D/g,'').replace(/^(33|0033)/,'0'); if (GE_CONFIG.TEL_EXCLUS.indexOf(dg) < 0) { tel = cand[ci]; break; } }
        }
        var nom = (f.expediteur || '').replace(/<.*$/,'').replace(/\(.*$/,'').trim();
        var notes = [rv.notes || '', (nom || tel) ? ('Contact : ' + nom + (tel ? ' - Tél : ' + tel : '')) : ''].filter(Boolean).join('\n');
        var url = 'https://calendar.google.com/calendar/render?action=TEMPLATE&authuser=' + encodeURIComponent(GE_CONFIG.MAIL)
          + '&text=' + encodeURIComponent(titre)
          + '&dates=' + cp(r.st) + '/' + cp(r.en) + '&ctz=Europe/Paris'
          + '&location=' + encodeURIComponent(rv.lieu || bien)
          + '&details=' + encodeURIComponent(notes)
          + (gs.length ? '&add=' + encodeURIComponent(gs.join(',')) : '');
        window.open(url, '_blank', 'noopener');
      });
      sec.appendChild(info); sec.appendChild(inv); sec.appendChild(bt);
      maj();
      rdvBox = sec;
      var detected = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(rv.debut || '');
      rdvBtn = el('button','btn' + (rdvOpen[f.id] ? ' on' : ''), '');
      rdvBtn.type = 'button';
      rdvBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#E8B84A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>Rendez-vous' + (detected ? ' <span class="dotb" title="Rendez-vous repéré dans le mail"></span>' : '');
      rdvBtn.addEventListener('click', function(){ rdvOpen[f.id] = !rdvOpen[f.id]; render(); });
    })();

    d.appendChild(contactSection(f));
    var rs = el('section','sec');
    rs.appendChild(el('h3','t','Répondre à ma façon'));
    var rp0 = reps[f.id];
    var waiting = !!(pending[f.id] && (!rp0 || rp0.ts < pending[f.id]) && (Date.now() / 1000 - pending[f.id] < 300));
    var hasDraft = !!(rp0 && rp0.brouillon_cree && rp0.brouillon_id && !waiting && !(fresh[f.id] && rp0.ts <= fresh[f.id]));
    var envE = hasDraft && envois[rp0.brouillon_id];
    var envLock = !!(envE && (envE.st === 'programme' || envE.st === 'envoye'));
    var ta = el('textarea','consigne'); ta.spellcheck = true; ta.lang = 'fr';
    ta.id = 'consigne';
    ta.rows = 3;
    ta.placeholder = hasDraft ? 'Ce que tu veux changer ou ajouter au brouillon' : 'Ex : refuse la baisse des honoraires, propose un appel demain';
    ta.value = waiting ? (sentTxt[f.id] || '') : (texts[f.id] || '');
    if (waiting || envLock) ta.disabled = true;
    ta.addEventListener('input', function(){ texts[f.id] = ta.value; });
    rs.appendChild(ta);
    var sb2 = el('button','btn send', waiting ? 'God Eye rédige…' : (hasDraft ? 'Améliorer le brouillon' : 'Préparer la réponse'));
    sb2.type = 'button';
    if (waiting) { sb2.disabled = true; sb2.classList.add('busy'); }
    else if (envLock) { sb2.disabled = true; sb2.title = 'Annule l’envoi pour modifier le brouillon'; }
    sb2.addEventListener('click', function(){
      var t = (ta.value || '').trim();
      if (!t) { say('Écris d\u2019abord ta consigne.'); return; }
      texts[f.id] = ''; sentTxt[f.id] = t;
      if (hasDraft) {
        replOld[f.id] = rp0.brouillon_id;
        sendConsigne(f, 'MODE : AMÉLIORER\nBROUILLON_ID : ' + rp0.brouillon_id + '\nCONSIGNE : ' + t.slice(0, 1200) + '\nTEXTE ACTUEL DU BROUILLON :\n' + String(txtOf(rp0)).slice(0, 2200));
      } else {
        sendConsigne(f, t);
      }
    });
    var prow = el('div','pjrow'); prow.appendChild(sb2); rs.appendChild(prow);
    if (hasDraft && !envLock) {
      var rz = el('button','btn undo','Repartir de zéro'); rz.type = 'button';
      rz.addEventListener('click', function(){
        if (!window.confirm('Supprimer le brouillon actuel et repartir de zéro ?')) return;
        supprBrouillon(rp0.brouillon_id);
        fresh[f.id] = rp0.ts; delete replOld[f.id]; texts[f.id] = ''; sentTxt[f.id] = '';
        render();
      });
      prow.appendChild(rz);
    }
    var rp = reps[f.id];
    var pjb = el('div','pjbar');
    pjDraw(pjb, f.id, function(){ return (rp && rp.brouillon_cree && (!pending[f.id] || rp.ts >= pending[f.id])) ? rp : null; });
    if (!envLock) prow.appendChild(pjb);
    if (rdvBtn) prow.appendChild(rdvBtn);
    if (rdvBox && rdvOpen[f.id]) rs.appendChild(rdvBox);
    var rdy = !!(rp && rp.brouillon_cree && (!pending[f.id] || rp.ts >= pending[f.id]));
    if (rdy && replOld[f.id] && !replBusy[f.id]) startReplace(f.id, rp);
    else if (rdy && pjOf(f.id).armed && !replBusy[f.id]) pjGo(f.id, rp);
    if (pending[f.id] && (!rp || rp.ts < pending[f.id])) {
      rs.appendChild(el('div','muted','God Eye rédige ta réponse, elle apparaît ici dans environ 1 minute.'));
    } else if (rp) {
      rs.appendChild(el('div','muted', rp.brouillon_cree ? 'Brouillon créé dans Gmail (non envoyé). Voici le texte.' : 'Brouillon non créé.'));
      var rw = el('div','repwrap');
      var rbx = el('div','repbox', txtOf(rp));
      rw.appendChild(rbx);
      var edSt = el('div','edst');
      if (rp.brouillon_cree && rp.brouillon_id && !envLock) editBox(rbx, edSt, function(){ return rp.brouillon_id; }, function(){ return txtOf(rp); }, function(t){ rp.texte = t; });
      var cb = el('button','cpico','\u29C9');
      cb.title = 'Copier le texte';
      cb.type = 'button';
      cb.addEventListener('click', function(){
        var tx = txtOf(rp);
        var ok = function(){ cb.textContent = 'Copié ✓'; setTimeout(function(){ cb.innerHTML = cbH; }, 1800); };
        var fb = function(){
          var t = document.createElement('textarea'); t.value = tx; t.style.position = 'fixed'; t.style.opacity = '0';
          document.body.appendChild(t); t.select();
          try { document.execCommand('copy'); ok(); } catch (e) { cb.textContent = '!'; }
          document.body.removeChild(t);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(tx).then(ok, fb); } else { fb(); }
      });
      rw.appendChild(cb);
      rs.appendChild(rw);
      rs.appendChild(edSt);
    }
    if (hasDraft) { var eb = el('div','envbar'); envBar(eb, rp0.brouillon_id); rs.appendChild(eb); }
    d.appendChild(rs);

    var act = el('div','actions');
    var isDone = !!done[f.id];
    var tb = el('button','btn ' + (isDone ? 'undo' : 'treat'), isDone ? 'Remettre à traiter' : '✓ Marquer comme traité');
    tb.type = 'button';
    tb.addEventListener('click', function(){
      setDone(f.id, !isDone);
      if (!isDone && !envProgGroupe(grp)) { var seenT = {}; (grp ? grp.all : [f]).forEach(function(x){ var t = x.thread || x.id; if (!seenT[t]) { seenT[t] = 1; deleteDrafts(t); } }); }
      selected = null; document.body.classList.remove('sel'); render();
    });
    act.appendChild(tb);
    var a = el('a','btn', f.brouillon_cree ? 'Ouvrir le fil et le brouillon dans Gmail' : 'Ouvrir le fil dans Gmail');
    a.href = GMAIL + encodeURIComponent(f.thread || f.id);
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    act.appendChild(a);
    var zb = el('button','btn','Tout télécharger (pièces jointes)'); zb.type = 'button';
    zb.addEventListener('click', function(){ telechargerTout(zb, f, grp); });
    act.appendChild(zb);
    d.appendChild(act);

    if (f.details && f.details.length){
      var det = el('details');
      det.appendChild(el('summary',null,'Fiche complète'));
      f.details.forEach(function(x){
        det.appendChild(el('h4',null,x.titre));
        det.appendChild(el('p',null,x.texte));
      });
      d.appendChild(det);
    }
    if (grp && grp.all.length > 1) {
      var hd = el('details');
      hd.appendChild(el('summary', null, 'Mails précédents de ce fil (' + (grp.all.length - 1) + ')'));
      grp.all.slice(1).forEach(function(x){
        hd.appendChild(el('h4', null, fmt(x.date) + ' · ' + (x.expediteur || '')));
        hd.appendChild(el('p', null, (x.urgence && x.urgence.texte) ? x.urgence.texte : (x.objet || '')));
        if (x.demandes && x.demandes.length) hd.appendChild(el('p', 'muted', 'Demandes : ' + x.demandes.join(' ; ')));
      });
      d.appendChild(hd);
    }
    if (hadFocus) { var t2 = document.getElementById('consigne'); if (t2) { t2.focus(); t2.setSelectionRange(t2.value.length, t2.value.length); } }
    d.appendChild(el('div','safe','God Eye n’envoie jamais rien tout seul. Un mail ne part que si tu cliques sur Envoyer ou Programmer.'));
  }


  // ---- Tout télécharger : récupère les pièces jointes de tous les mails du dossier et fabrique un zip ----
  var CRC_T = null;
  function crc32(u8){
    if (!CRC_T){ CRC_T = []; for (var n = 0; n < 256; n++){ var c = n; for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); CRC_T[n] = c >>> 0; } }
    var c2 = 0xFFFFFFFF; for (var i = 0; i < u8.length; i++) c2 = CRC_T[(c2 ^ u8[i]) & 255] ^ (c2 >>> 8); return (c2 ^ 0xFFFFFFFF) >>> 0;
  }
  function faireZip(items){
    var enc = new TextEncoder(), parts = [], central = [], off = 0;
    function w16(v, a){ a.push(v & 255, (v >>> 8) & 255); }
    function w32(v, a){ a.push(v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255); }
    items.forEach(function(it){
      var nm = enc.encode(it.name), crc = crc32(it.data), h = [];
      w32(0x04034b50, h); w16(20, h); w16(0x0800, h); w16(0, h); w16(0, h); w16(0x21, h);
      w32(crc, h); w32(it.data.length, h); w32(it.data.length, h); w16(nm.length, h); w16(0, h);
      parts.push(new Uint8Array(h), nm, it.data);
      var c = [];
      w32(0x02014b50, c); w16(20, c); w16(20, c); w16(0x0800, c); w16(0, c); w16(0, c); w16(0x21, c);
      w32(crc, c); w32(it.data.length, c); w32(it.data.length, c); w16(nm.length, c); w16(0, c); w16(0, c); w16(0, c); w16(0, c); w32(0, c); w32(off, c);
      central.push(new Uint8Array(c), nm);
      off += h.length + nm.length + it.data.length;
    });
    var csz = 0; central.forEach(function(x){ csz += x.length; });
    var e = []; w32(0x06054b50, e); w16(0, e); w16(0, e); w16(items.length, e); w16(items.length, e); w32(csz, e); w32(off, e); w16(0, e);
    return new Blob(parts.concat(central, [new Uint8Array(e)]), {type: 'application/zip'});
  }
  function b64u8(s){ var bin = atob(s), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
  function telechargerTout(btn, f, grp){
    if (btn.disabled) return;
    var label = btn.textContent;
    btn.disabled = true; btn.textContent = 'Recherche des pièces jointes…';
    var seenT = {}, ts = [];
    (grp ? grp.all : [f]).forEach(function(x){ var t = x.thread || x.id; if (/^[0-9a-f]{10,20}$/.test(t) && !seenT[t]){ seenT[t] = 1; ts.push(t); } });
    var fin = function(msg){ btn.textContent = msg; setTimeout(function(){ btn.textContent = label; btn.disabled = false; }, 3500); };
    fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=pjliste&t2=' + Date.now() + '&p=' + ts.join(','), {credentials:'include'})
      .then(function(r){ return r.json(); })
      .then(function(j){
        if (!j || !j.ok) { fin('Échec : script pas à jour ?'); return; }
        var files = j.files || [];
        if (!files.length) { fin('Aucune pièce jointe'); return; }
        var items = [], used = {}, fails = 0, idx = 0;
        function nom(n){
          n = String(n || 'fichier').replace(/[\\/:*?"<>|]+/g, '_');
          if (!used[n.toLowerCase()]) { used[n.toLowerCase()] = 1; return n; }
          var p = n.lastIndexOf('.'), base = p > 0 ? n.slice(0, p) : n, ext = p > 0 ? n.slice(p) : '', k = 2;
          while (used[(base + ' (' + k + ')' + ext).toLowerCase()]) k++;
          var r = base + ' (' + k + ')' + ext; used[r.toLowerCase()] = 1; return r;
        }
        function next(){
          if (idx >= files.length){
            if (!items.length) { fin('Échec du téléchargement'); return; }
            var blob = faireZip(items), a = document.createElement('a');
            var bien = String(f.bien || f.objet || 'dossier').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60);
            a.href = URL.createObjectURL(blob); a.download = 'God Eye - ' + bien + '.zip';
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
            setTimeout(function(){ URL.revokeObjectURL(a.href); }, 60000);
            fin(fails ? ('Zip prêt (' + fails + ' fichier(s) manquant(s))') : ('Zip prêt (' + items.length + ' fichiers)'));
            return;
          }
          var fl = files[idx++];
          btn.textContent = 'Téléchargement ' + idx + '/' + files.length + '…';
          fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=pjget&m=' + fl.m + '&i=' + fl.i, {credentials:'include'})
            .then(function(r){ return r.json(); })
            .then(function(g){ if (g && g.ok) items.push({name: nom(g.n || fl.n), data: b64u8(g.d)}); else fails++; next(); })
            .catch(function(){ fails++; next(); });
        }
        next();
      })
      .catch(function(){ fin('Échec de la connexion'); });
  }

  function select(k){
    selected = k;
    var g = groupOf(k);
    if (g) g.all.forEach(function(x){ markSeen(x.id); });
    document.body.classList.add('sel');
    render();
    window.scrollTo(0, 0);
  }
  var nv = {key: null, ts: 0, box: null};
  function nvInit(){
    if (nv.box) return;
    var hdr = document.getElementById('refresh');
    var nb = document.createElement('button');
    nb.id = 'newmail'; nb.type = 'button'; nb.className = 'refresh'; nb.title = 'Nouveau mail'; nb.setAttribute('aria-label', 'Nouveau mail');
    nb.textContent = '✎'; nb.style.marginRight = '8px';
    hdr.parentNode.insertBefore(nb, hdr);
    var box = document.createElement('section');
    box.className = 'sec'; box.style.display = 'none'; box.style.padding = '14px 22px 0';
    var trow = el('div',null,''); trow.style.display = 'flex'; trow.style.justifyContent = 'space-between'; trow.style.alignItems = 'center';
    trow.appendChild(el('h3','t','Nouveau mail'));
    var xb = el('button','btn undo','\u2715 Fermer'); xb.type = 'button';
    trow.appendChild(xb); box.appendChild(trow);
    var l1 = el('label','rdvl','Destinataire (adresse mail ou nom)');
    var inD = el('input','rdvi'); inD.type = 'text'; inD.placeholder = 'ex : harry@exemple.fr'; inD.autocomplete = 'off'; l1.appendChild(inD); var w1 = el('div'); w1.style.position = 'relative'; w1.appendChild(l1); suggestAttach(inD, w1); box.appendChild(w1);
    var l2 = el('label','rdvl','Ce que tu veux dire');
    var inT = el('textarea','consigne'); inT.spellcheck = true; inT.lang = 'fr'; inT.rows = 4; inT.placeholder = 'Ex : propose-lui la visite mardi 10 à 15h'; l2.appendChild(inT); box.appendChild(l2);
    var bt = el('button','btn send','Préparer le brouillon'); bt.type = 'button';
    var st = el('div','muted','');
    var rw = el('div','repwrap'); rw.style.display = 'none';
    var rb = el('div','repbox','');
    var cbH = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#E8B84A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 012-2h10"/></svg>Copier'; var cb = el('button','cpbtn',''); cb.innerHTML = cbH; cb.title = 'Copier le texte';
    rw.appendChild(rb); rw.appendChild(cb);
    cb.addEventListener('click', function(){
      var tx = rb.textContent || '';
      var ok = function(){ cb.textContent = '✓'; setTimeout(function(){ cb.textContent = '⧉'; }, 1500); };
      var fb = function(){ var t = document.createElement('textarea'); t.value = tx; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); ok(); } catch (e) {} document.body.removeChild(t); };
      if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(tx).then(ok, fb); } else { fb(); }
    });
    var ol = el('a','btn','Ouvrir le brouillon dans Gmail'); ol.target = '_blank'; ol.rel = 'noopener noreferrer'; ol.style.display = 'none'; ol.style.alignSelf = 'flex-start';
    var pjb = el('div','pjbar'); pjDraw(pjb, 'nv', null);
    var nrow = el('div','pjrow'); nrow.appendChild(bt); nrow.appendChild(pjb); var rz = el('button','btn undo','Repartir de zéro'); rz.type = 'button'; rz.style.display = 'none'; nrow.appendChild(rz); box.appendChild(nrow); box.appendChild(st); box.appendChild(rw); var edn = el('div','edst'); box.appendChild(edn); editBox(rb, edn, function(){ var r = nv.key && reps[nv.key]; return r && r.brouillon_id; }, function(){ return txtOf(nv.key && reps[nv.key]); }, function(t){ if (nv.key && reps[nv.key]) reps[nv.key].texte = t; }); box.appendChild(ol); var envn = el('div', 'envbar'); box.appendChild(envn);
    var cols = document.querySelector('.cols');
    cols.parentNode.insertBefore(box, cols);
    var closeBox = function(){
      box.style.display = 'none'; nb.textContent = '\u270E';
      if (nv.key && reps[nv.key]) { inD.value = ''; inT.value = ''; nv.key = null; rw.style.display = 'none'; ol.style.display = 'none'; st.textContent = ''; pjDraw(pjb, 'nv', null); nv.prev = null; nv.clearedFor = null; }
    };
    nb.addEventListener('click', function(){ if (box.style.display === 'none') { box.style.display = 'block'; nb.textContent = '\u2715'; } else { closeBox(); } });
    xb.addEventListener('click', closeBox);
    bt.addEventListener('click', function(){
      var d0 = (inD.value || '').trim(), m0 = (inT.value || '').trim();
      if (!d0 || !m0) { st.textContent = 'Il me faut le destinataire et ce que tu veux dire.'; return; }
      var key = Date.now().toString(16);
      var prev = nv.prev; nv.prev = null;
      var payload = prev
        ? 'MODE : AMÉLIORER\nBROUILLON_ID : ' + prev.id + '\nDESTINATAIRE : ' + d0 + '\nCONSIGNE : ' + m0.slice(0, 1200) + '\nTEXTE ACTUEL DU BROUILLON :\n' + String(prev.texte || '').slice(0, 2000)
        : 'DESTINATAIRE : ' + d0 + '\nMESSAGE : ' + m0;
      if (payload.length > 3900) { st.textContent = 'Message trop long.'; if (prev) nv.prev = prev; return; }
      if (prev) replOld.nv = prev.id;
      nv.key = key; nv.ts = Math.floor(Date.now() / 1000) - 2;
      pjs[key] = pjOf('nv'); pjs.nv = null; pjArm(key); pjDraw(pjb, key, null);
      rw.style.display = 'none'; ol.style.display = 'none';
      st.textContent = 'God Eye rédige ton mail, il apparaît ici dans environ 1 minute.';
      nvBar();
      localPost('/reponse', {thread: '0000000000', key: key, texte: payload})
        .then(function(r){ if (!r.ok) throw new Error('refus'); })
        .catch(function(){ nv.key = null; st.textContent = 'Récepteur local injoignable : God Eye est-il lancé sur le Mac ?'; nvBar(); });
    });
    nv.env = envn; nv.box = box; nv.ol = ol; nv.st = st; nv.rw = rw; nv.rb = rb; nv.bar = pjb; nv.bt = bt; nv.inT = inT; nv.inD = inD; nv.rz = rz;
    rz.addEventListener('click', function(){
      if (!window.confirm('Supprimer le brouillon actuel et repartir de zéro ?')) return;
      if (nv.prev) supprBrouillon(nv.prev.id);
      inD.value = ''; inT.value = ''; nv.key = null; nv.prev = null; nv.clearedFor = null;
      rw.style.display = 'none'; ol.style.display = 'none'; st.textContent = '';
      pjs.nv = null; delete replOld.nv;
      render();
    });
  }
  function nvRender(){
    nvInit();
    var r = nv.key ? reps[nv.key] : null;
    if (r && r.ts >= nv.ts) {
      nv.rb.textContent = txtOf(r);
      nv.rw.style.display = 'block';
      nv.ol.href = (r.brouillon_url && /^https:\/\/mail\.google\.com\//.test(r.brouillon_url)) ? r.brouillon_url : (GMAIL.split('#')[0] + '#drafts');
      nv.ol.style.display = 'inline-block';
      nv.st.textContent = r.brouillon_cree ? 'Brouillon créé dans Gmail (non envoyé). Vérifie le destinataire.' : 'Brouillon non créé.';
    }
  }
  function nvBar(){
    if (!nv.bar) return;
    var r = nv.key ? reps[nv.key] : null;
    var ready = (nv.key && r && r.ts >= nv.ts && r.brouillon_cree) ? r : null;
    var waiting = !!(nv.key && !ready && (Date.now() / 1000 - nv.ts < 300));
    var k = nv.key || 'nv';
    if (ready && ready.brouillon_id) nv.prev = {id: ready.brouillon_id, texte: txtOf(ready)};
    if (ready && replOld.nv && !replBusy.nv) startReplace('nv', ready);
    else if (ready && pjOf(k).armed && !replBusy.nv) pjGo(k, ready);
    if (ready && nv.clearedFor !== nv.key) { nv.clearedFor = nv.key; nv.inT.value = ''; }
    var imp = !!(nv.prev && !waiting);
    nv.bt.textContent = waiting ? 'God Eye rédige…' : (imp ? 'Améliorer le brouillon' : 'Préparer le brouillon');
    var eid = ready && ready.brouillon_id;
    var elk = !!(eid && envois[eid] && (envois[eid].st === 'programme' || envois[eid].st === 'envoye'));
    nv.bt.disabled = waiting || elk; nv.bt.classList.toggle('busy', waiting);
    nv.inT.disabled = waiting || elk; nv.inD.disabled = waiting || elk;
    if (eid) { nv.env.style.display = ''; envBar(nv.env, eid); } else { nv.env.style.display = 'none'; nv.env.textContent = ''; }
    nv.bar.style.display = elk ? 'none' : '';
    nv.inT.placeholder = imp ? 'Ce que tu veux changer ou ajouter au brouillon' : 'Ex : propose-lui la visite mardi 10 à 15h';
    nv.rz.style.display = (imp && !elk) ? '' : 'none';
    pjDraw(nv.bar, k, function(){ return ready; });
  }
  var PDV_QUARTIERS = [
    ['haut marais', 'Haut Marais', ['75003']], ['marais', 'Marais', ['75003', '75004']], ['montorgueil|sentier', 'Montorgueil / Sentier', ['75002']],
    ['opera', 'Opéra', ['75009', '75002']], ['grands boulevards', 'Grands Boulevards', ['75009', '75002']], ['champs elysees|triangle d\'or', 'Champs-Élysées', ['75008']],
    ['madeleine', 'Madeleine', ['75008', '75009']], ['saint lazare', 'Saint-Lazare', ['75008', '75009']], ['saint germain|odeon', 'Saint-Germain / Odéon', ['75006']],
    ['quartier latin|saint michel', 'Quartier latin', ['75005', '75006']], ['bastille', 'Bastille', ['75011', '75012', '75004']], ['oberkampf', 'Oberkampf', ['75011']],
    ['republique', 'République', ['75003', '75010', '75011']], ['canal saint martin', 'Canal Saint-Martin', ['75010']], ['gare du nord|gare de l\'est', 'Gares Nord / Est', ['75010']],
    ['montmartre', 'Montmartre', ['75018']], ['pigalle', 'Pigalle', ['75009', '75018']], ['batignolles', 'Batignolles', ['75017']], ['ternes', 'Ternes', ['75017']],
    ['etoile', 'Étoile', ['75008', '75016', '75017']], ['trocadero', 'Trocadéro', ['75016']], ['passy', 'Passy', ['75016']], ['auteuil', 'Auteuil', ['75016']],
    ['montparnasse', 'Montparnasse', ['75014', '75015', '75006']], ['convention', 'Convention', ['75015']], ['bercy', 'Bercy', ['75012']], ['nation', 'Nation', ['75011', '75012']],
    ['belleville', 'Belleville', ['75019', '75020']], ['menilmontant', 'Ménilmontant', ['75020']], ['buttes chaumont', 'Buttes-Chaumont', ['75019']], ['la villette|villette', 'La Villette', ['75019']],
    ['chatelet|les halles', 'Châtelet / Les Halles', ['75001', '75004']], ['louvre|palais royal', 'Louvre / Palais-Royal', ['75001']], ['vendome', 'Vendôme', ['75001']], ['bourse', 'Bourse', ['75002']],
    ['porte maillot', 'Porte Maillot', ['75016', '75017']], ['place d\'italie|butte aux cailles|bibliotheque', 'Italie / Butte-aux-Cailles', ['75013']], ['la defense', 'La Défense', ['92800', '92400']]
  ];
  var PDV_RUE_RE = /\b(rue|avenue|av|boulevard|bd|bld|quai|place|passage|cours|allee|impasse|faubourg|chaussee|route|villa|square)\s+((?:(?:de la|de l'|des|du|de|d'|les|la|le|l')\s*)?[a-z0-9][a-z0-9' -]{1,36}?)(?=\s+(?:a |dans|sur |max|min|loyer|prix|budget|pour|avec|paris|\d{5}|au |et |ou )|\s*[,;.]|\s*$)/g;
  function pdvAl(x){ return pdvNz(x).replace(/[^a-z0-9]+/g, ' ').trim(); }
  var PDV_COMMUNES = ['Boulogne-Billancourt|boulogne billancourt|boulogne', 'Bois-Colombes|bois colombes', 'La Garenne-Colombes|garenne colombes', 'Colombes|colombes', 'Asnières-sur-Seine|asnieres sur seine|asnieres', 'Courbevoie|courbevoie', 'Levallois-Perret|levallois perret|levallois', 'Neuilly-sur-Seine|neuilly sur seine|neuilly', 'Puteaux|puteaux', 'Nanterre|nanterre', 'Clichy|clichy', 'Gennevilliers|gennevilliers', 'Villeneuve-la-Garenne|villeneuve la garenne', 'Issy-les-Moulineaux|issy les moulineaux|issy', 'Vanves|vanves', 'Malakoff|malakoff', 'Montrouge|montrouge', 'Châtillon|chatillon', 'Clamart|clamart', 'Meudon|meudon', 'Sèvres|sevres', 'Saint-Cloud|saint cloud', 'Suresnes|suresnes', 'Rueil-Malmaison|rueil malmaison|rueil', 'Antony|antony', 'Bagneux|bagneux', 'Sceaux|sceaux', 'Chaville|chaville', 'Garches|garches', 'Le Plessis-Robinson|plessis robinson', 'Saint-Ouen|saint ouen', 'Saint-Denis|saint denis', 'Aubervilliers|aubervilliers', 'Pantin|pantin', 'Montreuil|montreuil', 'Bagnolet|bagnolet', 'Les Lilas|les lilas', 'Vincennes|vincennes', 'Saint-Mandé|saint mande', 'Charenton-le-Pont|charenton', 'Ivry-sur-Seine|ivry', 'Vitry-sur-Seine|vitry', 'Maisons-Alfort|maisons alfort', 'Nogent-sur-Marne|nogent', 'Créteil|creteil', 'Versailles|versailles', 'Argenteuil|argenteuil'];
  function pdvParse(txt){
    var t = ' ' + pdvNz(txt).replace(/m²|m2|metres? carres?/g, ' m2 ').replace(/\s+/g, ' ') + ' ';
    var rc = {type_bien: 'commerce', transactions: [], departements: [], codes_postaux: [], villes_quartiers: [], rues: [], quartiers: [], cps_quartier: [], surface_min: null, surface_max: null, loyer_max_mensuel: null, prix_max: null, max: 30};
    var m; var torig = t;
    if (/bureau/.test(t)) rc.type_bien = 'bureaux'; else if (/entrepot/.test(t)) rc.type_bien = 'entrepôt'; else if (/local sur cour/.test(t)) rc.type_bien = 'local sur cour';
    var add = function(x){ if (rc.transactions.indexOf(x) < 0) rc.transactions.push(x); };
    var murs = /\bmurs?\b/.test(t);
    if (/murs? libres?/.test(t)) add('Murs libres');
    if (/murs? occupes?/.test(t)) add('Murs occupés');
    if (murs && !rc.transactions.length) { add('Murs libres'); add('Murs occupés'); }
    if (/cession de bail|droit au bail/.test(t)) add('Cession de bail');
    if (/fonds/.test(t)) add('Fonds de commerce');
    if (!murs && /locati|louer|loyer/.test(t)) { add('Location pure'); add('Location avec droit d\'entrée'); }
    // surfaces
    var rm = function(re){ t = t.split(re).join(' '); };
    if ((m = t.match(/(\d{2,5})\s*(?:-|a|et)\s*(\d{2,5})\s*m2/))) { rc.surface_min = +m[1]; rc.surface_max = +m[2]; rm(m[0]); }
    if ((m = t.match(/(?:min(?:imum)?|a partir de|au moins|plus de|>)\s*(\d{2,5})\s*m2/))) { rc.surface_min = +m[1]; rm(m[0]); }
    if ((m = t.match(/(?:max(?:imum)?|jusqu'a|au plus|moins de|<)\s*(\d{2,5})\s*m2/))) { rc.surface_max = +m[1]; rm(m[0]); }
    if (rc.surface_min == null && rc.surface_max == null && (m = t.match(/(\d{2,5})\s*m2/))) { var v = +m[1]; rc.surface_min = Math.round(v * 0.8); rc.surface_max = Math.round(v * 1.25); rc.approx = true; rm(m[0]); }
    t = t.replace(/\d{2,5}\s*(?:-|a|et)\s*\d{2,5}\s*m2/g, ' ').replace(/\d{2,5}\s*m2/g, ' ');
    // rues puis quartiers
    var rmatch, reR = new RegExp(PDV_RUE_RE.source, 'g'), found = [];
    while ((rmatch = reR.exec(t))) {
      var core = pdvAl(rmatch[2].replace(/^(?:de la|de l'|des|du|de|d'|les|la|le|l')\s*/, ''));
      if (core && core.length > 2) { found.push(rmatch[0]); var lab = pdvAl(rmatch[1] + ' ' + core); if (rc.rues.indexOf(core) < 0) { rc.rues.push(core); rc.rues_lab = (rc.rues_lab || []).concat([lab]); } }
    }
    found.forEach(function(f2){ t = t.replace(f2, ' '); });
    PDV_QUARTIERS.forEach(function(q){
      var re = new RegExp('\\b(?:' + q[0] + ')\\b');
      if (re.test(t)) { rc.quartiers.push(q[1] + ' (' + q[2].join(', ') + ')'); q[2].forEach(function(c){ if (rc.codes_postaux.indexOf(c) < 0) { rc.codes_postaux.push(c); rc.cps_quartier.push(c); } }); t = t.replace(re, ' '); }
    });
    // zones
    var cp; var reCp = /\b(\d{5})\b/g;
    while ((cp = reCp.exec(t))) { if (rc.codes_postaux.indexOf(cp[1]) < 0) rc.codes_postaux.push(cp[1]); }
    t = t.replace(/\b\d{5}\b/g, ' ');
    var arr = function(n){ n = +n; if (n >= 1 && n <= 20) { var c = '750' + (n < 10 ? '0' : '') + n; if (rc.codes_postaux.indexOf(c) < 0) rc.codes_postaux.push(c); } };
    var reA = /paris\s*(\d{1,2})\s*(?:e|eme|er|ieme)?\b/g, am;
    while ((am = reA.exec(t))) arr(am[1]);
    t = t.replace(/paris\s*\d{1,2}\s*(?:e|eme|er|ieme)?\b/g, ' paris ');
    if (/paris/.test(t)) { var reB = /\b(\d{1,2})\s*(?:e|eme|er|ieme)\b/g, bm; while ((bm = reB.exec(t))) arr(bm[1]); t = t.replace(/\b\d{1,2}\s*(?:e|eme|er|ieme)\b/g, ' '); }
    PDV_COMMUNES.forEach(function(cm){
      var parts = cm.split('|'), disp = parts[0], alts = parts.slice(1);
      for (var ai = 0; ai < alts.length; ai++) {
        var words = alts[ai].split(' ');
        var re = new RegExp('(^|[^a-z0-9])' + words.join('[\\s\'-]+') + '(?![a-z0-9])');
        if (re.test(t)) { if (rc.villes_quartiers.indexOf(disp) < 0) rc.villes_quartiers.push(disp); t = t.replace(re, ' '); break; }
      }
    });
    var DEPS = [['hauts-de-seine|hauts de seine', '92'], ['seine-saint-denis|seine saint denis', '93'], ['val-de-marne|val de marne', '94'], ['val-d\'oise|val d\'oise', '95'], ['yvelines', '78'], ['essonne', '91'], ['seine-et-marne|seine et marne', '77'], ['petite couronne', '92,93,94,75']];
    DEPS.forEach(function(d){ if (new RegExp(d[0]).test(t)) { d[1].split(',').forEach(function(x){ if (rc.departements.indexOf(x) < 0) rc.departements.push(x); }); t = t.replace(new RegExp(d[0]), ' '); } });
    var reD = /(?:^|[\s,(])(75|77|78|91|92|93|94|95)(?=[\s,).]|$)/g, dm;
    while ((dm = reD.exec(t))) { if (rc.departements.indexOf(dm[1]) < 0) rc.departements.push(dm[1]); }
    if (/paris/.test(t) && !rc.codes_postaux.length && rc.departements.indexOf('75') < 0) rc.departements.push('75');
    if (!rc.villes_quartiers.length && (m = torig.match(/\b(?:a|sur|dans|vers|secteur)\s+([a-z' -]{3,30}?)(?=\s+(?:de|du|entre|max|min|avec|pour|loyer|prix|budget|\d)|\s*[,;.]|\s*$)/))) {
      var ville = m[1].trim();
      var inQ = ville && (rc.quartiers.some(function(q){ return pdvAl(q).indexOf(ville) >= 0; }) || rc.rues.some(function(r){ return r.indexOf(ville) >= 0; }));
      if (ville && !inQ && !/secteur|cible|zone|opportun|revue|recherch|rue |avenue|boulevard|quartier/.test(ville) && ['paris', 'louer', 'vendre', 'acheter', 'l\'achat', 'la location'].indexOf(ville) < 0 && !/^(un|une|le|la|les)\b/.test(ville)) rc.villes_quartiers.push(ville);
    }
    // argent
    var tgtLoyer = /loyer/.test(t) || (!murs && rc.transactions.some(function(x){ return /Location|Cession/.test(x); }) && !/prix|budget|achat/.test(t));
    var annual = /par an|\/ ?an|annuel|annee/.test(t);
    var reM = /(\d[\d ]*(?:[.,]\d+)?)\s*(k|m\b|millions?)?\s*(?:€|euros?|eur\b)?/g, mm, val = null, hasU = false;
    while ((mm = reM.exec(t))) {
      var n = parseFloat(mm[1].replace(/\s/g, '').replace(',', '.')); if (!isFinite(n)) continue;
      var u = mm[2] ? (mm[2] === 'k' ? 1000 : 1000000) : 1; var full = n * u;
      if (full < 1000 && !mm[2] && !/€|euro|eur/.test(mm[0]) && !/(loyer|prix|budget)\s*\S{0,12}\s*$/.test(t.slice(Math.max(0, mm.index - 22), mm.index))) continue;
      if (full < 100) continue;
      val = full; break;
    }
    if (val) { if (tgtLoyer) rc.loyer_max_mensuel = Math.round(annual || val > 20000 ? val / 12 : val); else rc.prix_max = Math.round(val); }
    return rc;
  }
  function pdvDesc(rc){
    var b = [rc.type_bien];
    if (rc.transactions.length) b.push(rc.transactions.join(' / '));
    if (rc.surface_min != null || rc.surface_max != null) b.push((rc.surface_min != null ? rc.surface_min : '') + '-' + (rc.surface_max != null ? rc.surface_max : '') + ' m²' + (rc.approx ? ' (±20 %)' : ''));
    if (rc.loyer_max_mensuel) b.push('loyer max ' + rc.loyer_max_mensuel + ' €/mois (' + Math.round(rc.loyer_max_mensuel * 12 / 1000) + ' k€/an)');
    if (rc.prix_max) b.push('prix max ' + rc.prix_max + ' €');
    var z = (rc.rues_lab || []).concat(rc.quartiers || []).concat(rc.codes_postaux.filter(function(c){ return (rc.cps_quartier || []).indexOf(c) < 0; })).concat((rc.villes_quartiers || []).length ? [] : rc.departements.map(function(d){ return 'dép. ' + d; })).concat(rc.villes_quartiers);
    b.push(z.length ? z.join(', ') : 'toute zone');
    return b.join(' · ');
  }
  var hs = {box: null};
  function pdvBoxInit(){
    if (hs.box) return;
    var hdr = document.getElementById('refresh'); if (!hdr) return;
    var anchor = document.getElementById('newrdv') || document.getElementById('newmail') || hdr;
    var hb = document.createElement('button');
    hb.id = 'searchpdv'; hb.type = 'button'; hb.className = 'refresh'; hb.title = 'Recherche biens'; hb.setAttribute('aria-label', 'Recherche biens');
    hb.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E8B84A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>';
    hb.style.marginRight = '8px'; hb.style.display = 'inline-flex'; hb.style.alignItems = 'center'; hb.style.justifyContent = 'center';
    hdr.parentNode.insertBefore(hb, anchor);
    var box = document.createElement('section');
    box.className = 'sec'; box.style.display = 'none'; box.style.padding = '14px 22px 0';
    var trow = el('div', null, ''); trow.style.display = 'flex'; trow.style.justifyContent = 'space-between'; trow.style.alignItems = 'center';
    trow.appendChild(el('h3', 't', 'Recherche biens'));
    var xb = el('button', 'btn undo', '✕ Fermer'); xb.type = 'button'; trow.appendChild(xb); box.appendChild(trow);
    var ta = el('textarea', 'consigne'); ta.rows = 2; ta.placeholder = 'Ex : restaurant 100-150 m² Paris 8e, loyer max 5000 €/mois'; box.appendChild(ta);
    var bt = el('button', 'btn send', 'Chercher'); bt.type = 'button'; bt.style.marginTop = '10px'; box.appendChild(bt);
    var info = el('div', 'muted', ''); info.style.marginTop = '8px'; box.appendChild(info);
    var out = el('div', null, ''); out.style.marginTop = '8px'; box.appendChild(out);
    var cols = document.querySelector('.cols'); cols.parentNode.insertBefore(box, cols);
    hs.box = box; hs.ta = ta; hs.info = info; hs.out = out; hs.bt = bt; hs.on = false;
    var closeBox = function(){ box.style.display = 'none'; hb.style.outline = ''; };
    hb.addEventListener('click', function(){
      if (box.style.display === 'none') {
        var nb = document.getElementById('newmail'); if (nb && nb.textContent === '✕') nb.click();
        var rb = document.getElementById('newrdv'); if (rb && rb.style.outline) rb.click();
        box.style.display = 'block'; hb.style.outline = '2px solid var(--gold)'; ta.focus();
        var g0 = selected && groupOf(selected); if (g0) hsFromFiche(g0.main);
      } else closeBox();
    });
    xb.addEventListener('click', closeBox);
    var go = function(){
      hs.srcId = null;
      var txt = ta.value.trim(); if (!txt) { info.textContent = 'Écris les critères.'; return; }
      var rc = pdvParse(txt);
      info.textContent = '→ ' + pdvDesc(rc);
      delete pdvRes.__home;
      pdvSearch({id: '__home', recherche: rc});
      hs.on = true; render();
    };
    bt.addEventListener('click', go);
    ta.addEventListener('keydown', function(e){ if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); go(); } });
  }
  function hsCrit(g){
    var base = {transactions: [], departements: [], codes_postaux: [], villes_quartiers: [], rues: [], quartiers: [], cps_quartier: []};
    if (g.recherche && typeof g.recherche === 'object') return Object.assign({}, base, g.recherche);
    var ch = (g.chiffres || []).filter(function(c){ return /loyer|prix|budget|surface/i.test(c.label || ''); }).map(function(c){ return (c.label || '') + ' ' + String(c.valeur || '').replace(/\([^)]*\)/g, ' '); }).join(' . ');
    var txt = [g.bien, (g.demandes || []).join(' '), g.resume_bien, ch].filter(Boolean).join(' . ');
    if (!/recherch|cherche|souhait|crit[eè]re|besoin/i.test(txt)) return null;
    var rc = pdvParse(txt);
    var has = rc.surface_min != null || rc.surface_max != null || rc.loyer_max_mensuel || rc.prix_max || rc.codes_postaux.length || rc.departements.length || rc.rues.length || rc.villes_quartiers.length;
    return has ? rc : null;
  }
  function hsFromFiche(f){
    if (!hs.box || (hs.srcId === f.id && pdvRes.__home)) return;
    var em = adrDe(f).toLowerCase();
    var pool = Object.keys(fiches).map(function(k){ return fiches[k]; }).filter(function(g){
      return g.id === f.id || (f.thread && g.thread === f.thread) || (em && adrDe(g).toLowerCase() === em);
    }).sort(function(a, b){ return new Date(b.date) - new Date(a.date); });
    var used = [], rc = null;
    pool.forEach(function(g){
      var c = hsCrit(g); if (!c) return;
      used.push(g);
      if (!rc) { rc = Object.assign({}, c, {max: 30}); return; }
      ['transactions', 'departements', 'codes_postaux', 'villes_quartiers', 'rues', 'quartiers', 'cps_quartier'].forEach(function(k){ if (!(rc[k] || []).length && (c[k] || []).length) rc[k] = c[k]; });
      if (rc.surface_min == null && rc.surface_max == null && (c.surface_min != null || c.surface_max != null)) { rc.surface_min = c.surface_min; rc.surface_max = c.surface_max; rc.approx = c.approx; }
      ['loyer_max_mensuel', 'prix_max', 'activite'].forEach(function(k){ if (!rc[k] && c[k]) rc[k] = c[k]; });
      if (!rc.rues_lab && c.rues_lab && !(rc.rues || []).length) rc.rues_lab = c.rues_lab;
    });
    if (!rc) { hs.info.textContent = 'Pas de critères de recherche dans cette analyse ni dans les autres mails de cette personne.'; return; }
    var desc = pdvDesc(rc);
    hs.ta.value = desc;
    hs.info.style.whiteSpace = 'pre-line';
    var src = used[0] && used[0].resume_bien ? '\nAnalyse : ' + used[0].resume_bien : '';
    hs.info.textContent = '→ ' + desc + (used.length > 1 ? ' (reconstitué à partir de ' + used.length + ' mails de ' + nomDe(f) + ')' : ' (depuis l’analyse du dossier)') + src;
    hs.srcId = f.id;
    delete pdvRes.__home;
    pdvSearch({id: '__home', recherche: rc});
    hs.on = true; render();
  }
  function pdvBoxUpdate(){
    if (!hs.box || !hs.on) return;
    var st = pdvRes.__home; var out = hs.out; out.textContent = '';
    if (!st) return;
    if (st.s === 'loading') { out.appendChild(el('div', 'muted', 'Recherche dans PDV Connect…')); return; }
    if (st.s === 'err') { out.appendChild(el('div', 'muted', st.msg || 'Recherche impossible.')); return; }
    if (!st.items.length) { out.appendChild(el('div', 'muted', 'Aucun bien actif ne correspond (' + st.seen + ' biens passés en revue).')); return; }
    var refs = st.items.map(function(it){ return it.ref; });
    var head = el('div', 'row sp'); head.appendChild(el('b', null, st.items.length + ' bien' + (st.items.length > 1 ? 's' : '')));
    var cb = el('button', 'btn undo', 'Copier les réf'); cb.type = 'button';
    cb.addEventListener('click', function(){ var tx = refs.join(', '); var ok = function(){ cb.textContent = '✓ Copié'; setTimeout(function(){ cb.textContent = 'Copier les réf'; }, 1500); }; if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(tx).then(ok, function(){}); });
    head.appendChild(cb); out.appendChild(head);
    st.items.forEach(function(it){
      var a = el('a', 'card'); a.href = 'https://www.pointdevente.fr/middle/produit.fiche/-/id/' + it.id; a.target = '_blank'; a.rel = 'noopener noreferrer'; a.style.marginTop = '8px';
      a.appendChild(el('span', 'bien', it.ref));
      a.appendChild(el('span', 'exp', it.adr));
      a.appendChild(el('span', 'obj', [it.trans, it.surf, it.loyer ? it.loyer + ' €/mois' : '', it.prix && it.prix !== '0 €' ? it.prix : '', it.cons].filter(Boolean).join(' · ')));
      out.appendChild(a);
    });
    out.appendChild(el('div', 'muted', 'Biens actifs uniquement.' + (GE_CONFIG.PDV_EXCLURE ? ' Ceux de ' + GE_CONFIG.PDV_EXCLURE + ' sont exclus.' : '')));
  }
  var rv0 = {box: null};
  function rdvInit(){
    if (rv0.box) return;
    var hdr = document.getElementById('refresh');
    if (!hdr) return;
    var nm = document.getElementById('newmail');
    var rb0 = document.createElement('button');
    rb0.id = 'newrdv'; rb0.type = 'button'; rb0.className = 'refresh'; rb0.title = 'Nouveau rendez-vous'; rb0.setAttribute('aria-label', 'Nouveau rendez-vous');
    var icoH = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E8B84A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>';
    rb0.innerHTML = icoH; rb0.style.marginRight = '8px'; rb0.style.display = 'inline-flex'; rb0.style.alignItems = 'center'; rb0.style.justifyContent = 'center';
    hdr.parentNode.insertBefore(rb0, nm || hdr);
    var box = document.createElement('section');
    box.className = 'sec'; box.style.display = 'none'; box.style.padding = '14px 22px 0';
    var trow = el('div', null, ''); trow.style.display = 'flex'; trow.style.justifyContent = 'space-between'; trow.style.alignItems = 'center';
    trow.appendChild(el('h3', 't', 'Nouveau rendez-vous'));
    var xb = el('button', 'btn undo', '✕ Fermer'); xb.type = 'button';
    trow.appendChild(xb); box.appendChild(trow);
    var mk = function(lbl, ph, tag){
      var l = el('label', 'rdvl', lbl);
      var i = el(tag || 'input', tag === 'textarea' ? 'consigne' : 'rdvi');
      if (!tag) i.type = 'text';
      if (tag === 'textarea') i.rows = 2;
      i.placeholder = ph; l.appendChild(i); box.appendChild(l);
      return i;
    };
    var curF = null;
    var lsel = el('label', 'rdvl', 'Mail du client ou adresse du bien');
    var sel0 = el('input', 'rdvi'); sel0.type = 'text'; sel0.placeholder = 'Ex : marie_anne.chapalain@hotmail.fr ou 12 rue de Rivoli'; lsel.appendChild(sel0); box.appendChild(lsel);
    var lres = el('div', 'muted', ''); box.appendChild(lres);
    var lchoix = el('div', 'actions', ''); lchoix.style.marginTop = '6px'; box.appendChild(lchoix);
    var inQ = mk('Date et heure', 'Ex : mardi 10 à 15h  (ajoute « 30 min » ou « pendant 1h30 » pour la durée)', 'textarea');
    var info = el('div', 'muted', ''); box.appendChild(info);
    var inT = mk('Titre (facultatif)', 'Ex : Visite 12 rue de Rivoli, sinon le type est déduit');
    var inL = mk('Lieu', 'Adresse ou nom du lieu');
    var inV = mk('Invités', 'Adresses mail, séparées par une virgule');
    var inC = mk('Téléphone du client', 'Ajouté dans les notes');
    wrapSuggest(sel0, {plain: true}); wrapSuggest(inV, {multi: true});
    var inN = mk('Notes (facultatif)', 'Ce qui doit apparaître dans l’invitation', 'textarea');
    var bt = el('button', 'btn send', 'Ouvrir dans Google Agenda'); bt.type = 'button';
    bt.style.marginTop = '12px'; box.appendChild(bt);
    var cols = document.querySelector('.cols');
    cols.parentNode.insertBefore(box, cols);
    var calc = function(){
      var r = parseRdv(inQ.value, new Date());
      if (!r.date || r.h === null || r.h > 23 || r.mi > 59) return null;
      r.st = new Date(r.date.getFullYear(), r.date.getMonth(), r.date.getDate(), r.h, r.mi);
      r.en = new Date(r.st.getTime() + r.dur * 60000);
      return r;
    };
    var telOf = function(f){
      var tel = f.telephone_client || '';
      if (!tel) {
        var cand = JSON.stringify(f).match(/(?:\+33|0033|0)[\s.]?[1-9](?:[\s.-]?\d{2}){4}/g) || [];
        for (var ci = 0; ci < cand.length; ci++) { var dg = cand[ci].replace(/\D/g,'').replace(/^(33|0033)/,'0'); if (GE_CONFIG.TEL_EXCLUS.indexOf(dg) < 0) { tel = cand[ci]; break; } }
      }
      return tel;
    };
    var fillFrom = function(f, qmail){
      curF = f;
      if (!f) { [inT, inL, inV, inC, inN].forEach(function(x){ x.value = ''; }); maj(); return; }
      var rv = f.rdv || {};
      var bien = (f.bien && f.bien !== 'non communiqué') ? f.bien : '';
      var em = ((f.expediteur || '').match(/[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+/i) || [''])[0];
      var ok = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(rv.debut || '');
      if (ok) inQ.value = rv.debut.slice(8,10) + '/' + rv.debut.slice(5,7) + ' ' + rv.debut.slice(11,13) + 'h' + rv.debut.slice(14,16);
      inT.value = rv.titre || '';
      inL.value = rv.lieu || bien;
      var pm = qmail || em;
      inV.value = (pm && !moi(pm)) ? pm : '';
      inC.value = telOf(f);
      inN.value = rv.notes || '';
      maj();
    };
    var nzs = function(x){ return (x || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); };
    var cherche = function(){
      var q = sel0.value.trim();
      lchoix.textContent = ''; lres.textContent = '';
      if (!q) { fillFrom(null); return; }
      var qm = (q.match(/[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+/i) || [''])[0].toLowerCase();
      var all = groups(), hits = [];
      if (qm) {
        hits = all.filter(function(g){ return g.all.some(function(f){ return JSON.stringify(f).toLowerCase().indexOf(qm) >= 0; }); });
      } else {
        var stop = ['rue','de','du','la','le','les','des','avenue','av','bd','boulevard','paris','et'];
        var raw = nzs(q).replace(/[^a-z0-9]+/g, ' ').split(' ').filter(Boolean);
        var toks = raw.filter(function(w){ return stop.indexOf(w) < 0; });
        if (!toks.length) toks = raw;
        var scored = all.map(function(g){
          var txt = ' ' + nzs(g.all.map(function(f){ return [f.bien, f.objet, f.resume_bien, JSON.stringify(f.details || '')].join(' '); }).join(' ')).replace(/[^a-z0-9]+/g, ' ') + ' ';
          var n = 0; toks.forEach(function(w){ if (txt.indexOf(' ' + w) >= 0) n++; });
          return {g: g, n: n};
        });
        var full = scored.filter(function(x){ return toks.length && x.n === toks.length; });
        var part = scored.filter(function(x){ return toks.length > 2 && x.n >= Math.ceil(toks.length * 0.7); });
        hits = (full.length ? full : part).map(function(x){ return x.g; });
      }
      var lib = function(g){ return (g.main.bien && g.main.bien !== 'non communiqué' ? g.main.bien : (g.main.objet || 'Mail')) + ' · ' + nomDe(g.main); };
      if (!hits.length) {
        fillFrom(null);
        if (qm) inV.value = moi(qm) ? '' : qm; else inL.value = q;
        lres.textContent = 'Aucun dossier trouvé, le rendez-vous ne sera pas lié.';
      } else if (hits.length === 1) {
        fillFrom(hits[0].main, qm);
        lres.textContent = '→ Dossier : ' + lib(hits[0]);
      } else {
        fillFrom(null);
        if (qm) inV.value = moi(qm) ? '' : qm; else inL.value = q;
        lres.textContent = hits.length + ' dossiers correspondent, choisis le bon.';
        hits.slice(0, 6).forEach(function(g){
          var b = el('button', 'btn undo', lib(g)); b.type = 'button';
          b.addEventListener('click', function(){ fillFrom(g.main, qm); lchoix.textContent = ''; lres.textContent = '→ Dossier : ' + lib(g); });
          lchoix.appendChild(b);
        });
      }
    };
    var tmr = null;
    sel0.addEventListener('input', function(){ clearTimeout(tmr); tmr = setTimeout(cherche, 250); });
    var maj = function(){
      var r = calc();
      if (!r) { info.textContent = inQ.value.trim() ? 'Il me faut une date et une heure (ex : mardi 10 à 15h).' : ''; return; }
      info.textContent = '→ ' + r.st.toLocaleDateString('fr-FR', {weekday: 'long', day: 'numeric', month: 'long'}) + ' à ' + r.st.getHours() + 'h' + (r.st.getMinutes() < 10 ? '0' : '') + r.st.getMinutes() + ', ' + r.dur + ' min';
    };
    inQ.addEventListener('input', maj);
    var reset = function(){ [inQ, inT, inL, inV, inC, inN].forEach(function(x){ x.value = ''; }); info.textContent = ''; sel0.value = ''; lres.textContent = ''; lchoix.textContent = ''; curF = null; };
    var closeBox = function(){ box.style.display = 'none'; rb0.style.outline = ''; };
    var openBox = function(){
      var nb = document.getElementById('newmail');
      if (nb && nb.textContent === '✕') nb.click();
      box.style.display = 'block'; rb0.style.outline = '2px solid var(--gold)';
      if (selected && !sel0.value && groupOf(selected)) { var g0 = groupOf(selected).main; fillFrom(g0); lres.textContent = '→ Dossier : ' + ((g0.bien && g0.bien !== 'non communiqué') ? g0.bien : (g0.objet || 'Mail')) + ' · ' + nomDe(g0); }
    };
    rb0.addEventListener('click', function(){ if (box.style.display === 'none') openBox(); else closeBox(); });
    xb.addEventListener('click', closeBox);
    if (nm) nm.addEventListener('click', function(){ if (box.style.display !== 'none') closeBox(); });
    bt.addEventListener('click', function(){
      var r = calc();
      if (!r) { maj(); if (!info.textContent) info.textContent = 'Écris la date et l’heure.'; return; }
      var pad = function(n){ return (n < 10 ? '0' : '') + n; };
      var cp = function(d){ return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + 'T' + pad(d.getHours()) + pad(d.getMinutes()) + '00'; };
      var gs = r.emails.slice();
      (inV.value.match(/[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+/gi) || []).forEach(function(m){ gs.push(m); });
      gs = gs.filter(function(m, k){ return !moi(m) && gs.indexOf(m) === k; });
      var nz = function(x){ return (x || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); };
      var types = [['visite', 'Visite'], ['appel|telephon|rappel|call', 'Appel'], ['signature|signer', 'Signature'], ['estimation|avis de valeur|valorisation', 'Estimation'], ['reunion|point ', 'Réunion'], ['visio|teams|zoom|meet', 'Visio']];
      var typ = 'RDV';
      var ctxs = [nz(inT.value), nz(inQ.value), nz(inN.value)];
      if (curF) ctxs.push(nz(curF.objet) + ' ' + nz((curF.demandes || []).join(' ')) + ' ' + nz(curF.reponse));
      for (var ci = 0; ci < ctxs.length && typ === 'RDV'; ci++) {
        for (var ti = 0; ti < types.length; ti++) { if (new RegExp(types[ti][0]).test(ctxs[ci])) { typ = types[ti][1]; break; } }
      }
      var lieu = inL.value.trim();
      var t0 = inT.value.trim();
      var titre = t0 ? ((typ !== 'RDV' && nz(t0).indexOf(nz(typ)) !== 0) ? typ + ' ' + t0 : t0) : (typ + ' ' + lieu).trim();
      var nomC = curF ? (curF.expediteur || '').replace(/<.*$/,'').replace(/\(.*$/,'').replace(/["]/g,'').trim() : '';
      var tel = inC.value.trim();
      var notes = [inN.value.trim(), (nomC || tel) ? ('Contact : ' + nomC + (tel ? ' - Tél : ' + tel : '')) : ''].filter(Boolean).join('\n');
      var url = 'https://calendar.google.com/calendar/render?action=TEMPLATE&authuser=' + encodeURIComponent(GE_CONFIG.MAIL)
        + '&text=' + encodeURIComponent(titre)
        + '&dates=' + cp(r.st) + '/' + cp(r.en) + '&ctz=Europe/Paris'
        + '&location=' + encodeURIComponent(lieu)
        + '&details=' + encodeURIComponent(notes)
        + (gs.length ? '&add=' + encodeURIComponent(gs.join(',')) : '');
      window.open(url, '_blank', 'noopener');
      reset(); closeBox();
    });
    rv0.box = box;
  }
  function tipify(){
    ['searchpdv', 'newrdv', 'newmail', 'refresh'].forEach(function(id){
      var b = document.getElementById(id); if (!b) return;
      var t = b.getAttribute('title') || b.getAttribute('data-tip') || b.getAttribute('aria-label');
      if (t) { b.setAttribute('data-tip', t); b.removeAttribute('title'); }
    });
  }
  function render(){ if (editing) return; renderList(); renderDetail(); nvRender(); nvBar(); rdvInit(); pdvBoxInit(); pdvBoxUpdate(); tipify(); }

  function addScript(src, cb){
    var s = document.createElement('script');
    s.src = src + '?t=' + Date.now();
    s.onload = function(){ s.remove(); if (cb) cb(); };
    s.onerror = function(){ s.remove(); };
    document.head.appendChild(s);
  }
  function refresh(){
    window.GODEYE_IDS = [];
    addScript('panel/index.js', function(){
      (window.GODEYE_IDS || []).forEach(function(id){
        if (loaded[id]) return;
        loaded[id] = 1;
        addScript('panel/' + id + '.js');
      });
      window.GODEYE_REPS = [];
      addScript('panel/reps.js', function(){
        (window.GODEYE_REPS || []).forEach(function(nm){
          if (repsLoaded[nm]) return;
          repsLoaded[nm] = 1;
          addScript('panel/rep-' + nm + '.js');
        });
      });
      var n = new Date();
      if (!window.__keep) document.getElementById('maj').textContent = 'Mis à jour ' + n.toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'});
    });
  }
  render();
  refresh();
  document.getElementById('refresh').addEventListener('click', refreshNow);
  var auto = {};
  try { auto = JSON.parse(localStorage.getItem('godeye_auto') || '{}'); } catch(e) {}
  var autolu = {};
  var relances = {}, luAt = {};
  try { relances = JSON.parse(localStorage.getItem('godeye_relances') || '{}'); } catch(e) {}
  try { luAt = JSON.parse(localStorage.getItem('godeye_luat') || '{}'); } catch(e) {}
  var DELAI_RELANCE = 3 * 24 * 3600 * 1000;
  function saveRel(){ try { localStorage.setItem('godeye_relances', JSON.stringify(relances)); localStorage.setItem('godeye_luat', JSON.stringify(luAt)); } catch(e) {} }
  var luSeen = {};
  try { luSeen = JSON.parse(localStorage.getItem('godeye_luseen') || '{}'); } catch(e) {}
  var DELAI_LU = 10 * 60 * 1000;
  try { autolu = JSON.parse(localStorage.getItem('godeye_autolu') || '{}'); } catch(e) {}
  function autoTraite(){
    var cand = [], rev = [];
    groups().forEach(function(g){
      var m = g.main, t = m.thread || m.id;
      if (!/^[0-9a-f]{10,20}$/.test(t)) return;
      if (done[m.id] && autolu[m.id]) { if (rev.indexOf(t) < 0) rev.push(t); return; }
      if (done[m.id] || auto[m.id]) return;
      if (cand.indexOf(t) < 0) cand.push(t);
    });
    var lstA = cand.slice(0, 25).concat(rev.slice(0, 25)).join(',');
    var lstB = cand.slice(0, 25).concat(rev.slice(0, 25)).join(',');
    function pull(act, lst){ return fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=' + act + '&m=' + lst, {credentials:'include'}).then(function(r){ return r.json(); }).catch(function(){ return null; }); }
    Promise.all([pull('repondus', lstA), pull('dejalus', lstB)])
      .then(function(rs){
        var j = rs[0], k = rs[1];
        var okA = !!(j && j.ok && j.ids), okB = !!(k && k.ok && k.ids);
        if (!okA && !okB) return;
        var rep = {}, lu = {};
        if (okA) j.ids.concat(j.dbg || []).forEach(function(i){ rep[i] = 1; });
        if (okB) k.ids.forEach(function(i){ lu[i] = 1; });
        var changed = false, back = false, relance = false;
        groups().forEach(function(g){
          var m = g.main, t = m.thread || m.id;
          if (done[m.id] && autolu[m.id]) {
            // remis en non lu dans Gmail : le dossier revient dans À traiter
            if (okB && !lu[t]) { delete autolu[m.id]; delete auto[m.id]; delete luAt[m.id]; setDone(m.id, false); back = true; return; }
            // relance : lu automatiquement, sans réponse de ta part depuis 3 jours (jamais pour un « traité » cliqué à la main)
            if (okA && rep[t]) { delete autolu[m.id]; delete luAt[m.id]; saveRel(); changed = true; return; }
            if (!luAt[m.id]) { luAt[m.id] = Date.now(); saveRel(); return; }
            if (okA && Date.now() - luAt[m.id] >= DELAI_RELANCE) {
              delete autolu[m.id]; delete auto[m.id]; delete luAt[m.id]; relances[m.id] = 1; setDone(m.id, false); saveRel(); relance = true;
            }
            return;
          }
          if (done[m.id] || auto[m.id]) return;
          if (okB && !lu[t] && luSeen[m.id]) { delete luSeen[m.id]; try { localStorage.setItem('godeye_luseen', JSON.stringify(luSeen)); } catch(e) {} }
          if (!rep[t] && !lu[t]) return;
          if (!rep[t]) {
            // simplement lu : on laisse 10 min, et on ne touche pas au dossier ouvert dans le panneau
            var now = Date.now();
            if (!luSeen[m.id]) { luSeen[m.id] = now; try { localStorage.setItem('godeye_luseen', JSON.stringify(luSeen)); } catch(e) {} }
            if (now - luSeen[m.id] < DELAI_LU) return;
            var sg = selected && groupOf(selected);
            if (sg && sg.main.id === m.id) return;
          }
          auto[m.id] = 1; setDone(m.id, true); changed = true;
          if (!rep[t]) { autolu[m.id] = 1; luAt[m.id] = Date.now(); saveRel(); }
          var seenT = {};
          if (!envProgGroupe(g)) g.all.forEach(function(x){ var tt = x.thread || x.id; if (!seenT[tt]) { seenT[tt] = 1; deleteDrafts(tt); } });
        });
        if (changed || back || relance) {
          try { localStorage.setItem('godeye_auto', JSON.stringify(auto)); } catch(e) {}
          try { localStorage.setItem('godeye_autolu', JSON.stringify(autolu)); } catch(e) {}
          render();
          say(relance ? 'Relance : un dossier lu sans réponse depuis 3 jours est revenu dans À traiter' : back ? 'Mail remis en non lu : dossier revenu dans À traiter' : 'Mail ouvert ou répondu : dossier passé en traité');
        }
      })
      .catch(function(){});
  }
  setTimeout(autoTraite, 15000);
  setInterval(autoTraite, 120000);
  setTimeout(envPull, 3000); setInterval(envPull, 60000);
  var cleaned = {};
  try { cleaned = JSON.parse(localStorage.getItem('godeye_clean') || '{}'); } catch (e) {}
  function nettoieCopies(){
    var ids = Object.keys(fiches).filter(function(k){ return /^[0-9a-f]{10,20}$/.test(k) && !cleaned[k]; }).slice(0, 15);
    if (!ids.length) return;
    fetch(DEL_URL + '?t=' + DEL_TOKEN + '&a=suppr&m=' + ids.join(','), {credentials:'include'})
      .then(function(r){ return r.json(); })
      .then(function(j){
        if (!j || !j.ok) return;
        ids.forEach(function(k){ cleaned[k] = 1; });
        var ks = Object.keys(cleaned);
        if (ks.length > 800) { ks.slice(0, ks.length - 600).forEach(function(k){ delete cleaned[k]; }); }
        try { localStorage.setItem('godeye_clean', JSON.stringify(cleaned)); } catch (e) {}
      })
      .catch(function(){});
  }
  setTimeout(nettoieCopies, 20000);
  setInterval(nettoieCopies, 120000);
  setInterval(refresh, 10000);
  // ---- rechargement automatique après une mise à jour (version.txt est écrit par maj-auto.pl) ----
  (function(){
    var vu = null;
    function lireVersion(cb){
      try { fetch('version.txt?t=' + Date.now(), {cache: 'no-store'}).then(function(r){ return r.ok ? r.text() : ''; }).then(function(t){ cb(String(t || '').trim()); }).catch(function(){ cb(''); }); } catch (e) { cb(''); }
    }
    lireVersion(function(v){ vu = v; });
    setInterval(function(){
      lireVersion(function(v){
        if (!vu || !v || v === vu) return;
        vu = v;
        try { if (window.chrome && chrome.runtime && chrome.runtime.reload) chrome.runtime.reload(); else location.reload(); } catch (e) { location.reload(); }
      });
    }, 120000);
  })();
})();

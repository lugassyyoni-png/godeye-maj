#!/bin/bash
cd "$(dirname "$0")" || exit 1
export PATH="$PATH:/opt/homebrew/bin:/usr/local/bin:$HOME/.local/bin"
CLAUDE="${GODEYE_CLAUDE:-}"
[ -n "$CLAUDE" ] || CLAUDE=$(ls "$HOME/.local/bin/claude" /opt/homebrew/bin/claude /usr/local/bin/claude 2>/dev/null | head -n 1)
[ -n "$CLAUDE" ] || { echo "claude introuvable" >> log.txt; exit 1; }
mkdir -p fiches
touch done.txt
# verrou : jamais deux passages en meme temps (un verrou de plus de 20 min est considere comme mort)
if [ -d .lock ]; then
  if [ -n "$(find .lock -maxdepth 0 -mmin +20)" ]; then rmdir .lock; else exit 0; fi
fi
mkdir .lock 2>/dev/null || exit 0
trap 'rmdir .lock' EXIT
# mise a jour automatique de God Eye (au plus une verification toutes les 30 minutes, sans effet si maj.conf est absent)
perl maj-auto.pl >> log.txt 2>&1 || true
# done.txt est reconstruit par le script : anciens ids + toutes les fiches deja ecrites
{ cat done.txt; ls fiches | sed 's/\..*//'; } | grep -E '^[0-9a-f]+$' | sort -u > done.tmp && mv done.tmp done.txt
# fils.txt : une ligne par fiche (threadId puis identifiant de fiche), pour regrouper les mails d'un meme expediteur et d'un meme sujet
perl fils.pl
# mise a jour unique de consigne.md : ordre du plus ancien au plus recent, 10 mails par passage, cle "recherche" dans les fiches
perl maj-consigne.pl consigne.md
echo "--- $(date '+%Y-%m-%d %H:%M:%S')" >> log.txt
"$CLAUDE" -p "$(cat consigne.md)" --model sonnet --allowedTools "mcp__claude_ai_Gmail__list_drafts,mcp__claude_ai_Gmail__get_draft,mcp__claude_ai_Gmail__get_thread,mcp__claude_ai_Gmail__get_message,mcp__claude_ai_Gmail__create_draft,mcp__claude_ai_Gmail__update_draft,Read,Write,ToolSearch" --disallowedTools "mcp__claude_ai_Gmail__send_message,Bash" >> log.txt 2>&1
# panneau : transforme les fiches en fichiers lus par panel.html (sans rien installer)
mkdir -p extension/panel
ids=""
for f in fiches/*.json; do
  [ -f "$f" ] || continue
  id=$(basename "$f" .json)
  { printf 'window.godeyeAdd('; cat "$f"; printf ');\n'; } > "extension/panel/$id.js"
  ids="$ids\"$id\","
done
printf 'window.GODEYE_IDS=[%s];\n' "${ids%,}" > extension/panel/index.js
# apprentissage : toutes les 6 h environ, compare les brouillons proposes a ce que l'utilisateur a vraiment envoye
if [ ! -f .appris-stamp ] || [ -n "$(find .appris-stamp -mmin +360)" ]; then
  ls apprentissage | sed 's/\..*//' > apprises.txt
  echo "--- apprentissage $(date '+%Y-%m-%d %H:%M:%S')" >> log.txt
  "$CLAUDE" -p "$(cat consigne-apprentissage.md)" --model sonnet --allowedTools "mcp__claude_ai_Gmail__get_thread,mcp__claude_ai_Gmail__get_message,Read,Write,ToolSearch" --disallowedTools "mcp__claude_ai_Gmail__send_message,mcp__claude_ai_Gmail__create_draft,mcp__claude_ai_Gmail__update_draft,Bash" >> log.txt 2>&1
  touch .appris-stamp
fi

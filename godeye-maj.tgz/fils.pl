#!/usr/bin/perl
# Regroupe les mails d'un même expéditeur et d'un même sujet (numéros, "Re:", pièces/documents ignorés).
use strict; use warnings; use utf8;
use JSON::PP; use File::Basename;
binmode(STDOUT, ':utf8');
sub norm {
  my ($d) = @_;
  my $exp = lc($d->{expediteur} // '');
  my ($m) = $exp =~ /([a-z0-9._+-]+@[a-z0-9.-]+)/;
  my $s = lc($d->{objet} // '');
  $s =~ s/^(\s*(re|tr|fwd?|rép)\s*:\s*)+//;
  $s =~ s/\(\s*\d+\s*\)/ /g;
  $s =~ s/\bpi[èe]ces?\b/documents/g;
  $s =~ s/\bdocuments?\b/documents/g;
  $s =~ s/\battendu(e|s|es)?\b/attendu/g;
  $s =~ s/[^a-z0-9àâçéèêëîïôûùü]+/ /g;
  $s =~ s/^\s+|\s+$//g;
  return $s ne '' ? ($m // '') . '|' . $s : '';
}
my @fs;
for my $p (glob("fiches/*.json")) {
  eval {
    open(my $fh, '<:raw', $p) or die; local $/; my $raw = <$fh>; close $fh;
    my $d = JSON::PP->new->utf8->decode($raw);
    my $id = basename($p, '.json');
    push @fs, [ ($d->{date} // ''), $id, ($d->{thread} || $id), norm($d) ];
  };
}
@fs = sort { $a->[0] cmp $b->[0] or $a->[1] cmp $b->[1] } @fs;
my (%first, @out);
for my $f (@fs) {
  my ($date, $i, $t, $n) = @$f;
  $first{$n} = $t if $n ne '' && !exists $first{$n};
  push @out, ($n ne '' ? $first{$n} : $t) . " $i";
}
open(my $o, '>', 'fils.txt') or exit 1;
print $o join("\n", @out), "\n";
close $o;

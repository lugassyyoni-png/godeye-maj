#!/usr/bin/perl
# God Eye : mise à jour automatique. Lancé par godeye.sh à chaque passage, dans le dossier GodEye.
# Lit maj.conf (BASE=adresse du dépôt, SECRET=clé de signature, TOKEN=facultatif, INTERVALLE=minutes).
# Ne remplace rien sans avoir vérifié la signature, la liste des fichiers et leur syntaxe.
# Ne touche jamais à config.js, consigne*.md (sauf maj-consigne.pl), fiches, jetons.
use strict; use warnings; use utf8;
use File::Basename qw(dirname);
use File::Path qw(make_path remove_tree);
use File::Temp qw(tempdir);
use File::Copy qw(copy);
use Digest::SHA qw(sha256_hex hmac_sha256_hex);
use JSON::PP;
use Cwd qw(getcwd);

my $DIR = getcwd();
sub logm { if (open(my $l, '>>:utf8', "$DIR/log.txt")) { print $l 'maj: ', join(' ', @_), "\n"; close $l; } }
sub lire { my ($f) = @_; open(my $h, '<:raw', $f) or return undef; local $/; my $c = <$h>; close $h; return $c; }
sub ecrire { my ($f, $c) = @_; open(my $h, '>:raw', $f) or return 0; print $h $c; close $h; return 1; }
sub notif {
  my ($titre, $msg) = @_;
  return unless -x '/usr/bin/osascript';
  $msg =~ s/["\\]/ /g; $titre =~ s/["\\]/ /g;
  system('/usr/bin/osascript', '-e', qq{display notification "$msg" with title "$titre"});
}

# --- réglages
my %C;
if (open(my $h, '<:encoding(UTF-8)', "$DIR/maj.conf")) {
  while (my $l = <$h>) { $l =~ s/\r?\n$//; next if $l =~ /^\s*(#|$)/; $C{$1} = $2 if $l =~ /^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/; }
  close $h;
}
my $BASE = $C{BASE} || ''; $BASE =~ s{/+$}{};
my $SECRET = $C{SECRET} || '';
my $INTERV = ($C{INTERVALLE} && $C{INTERVALLE} =~ /^\d+$/) ? $C{INTERVALLE} : 30;
exit 0 unless $BASE && length($SECRET) >= 16;

# --- au plus une vérification toutes les INTERVALLE minutes
my $marq = "$DIR/.maj-check";
if (-f $marq && (-M $marq) * 1440 < $INTERV) { exit 0; }
ecrire($marq, time() . "\n");

sub telecharger {
  my ($url, $dest) = @_;
  my @cmd = ('curl', '-fsSL', '--max-time', '60', '--max-filesize', '8000000', '-o', $dest);
  push @cmd, '-H', 'Authorization: Bearer ' . $C{TOKEN} if $C{TOKEN};
  push @cmd, $url . '?t=' . time();
  return system(@cmd) == 0 && -s $dest;
}

my $tmp = tempdir('godeye-maj-XXXXXX', DIR => $DIR, CLEANUP => 1);

# --- 1) numéro de version publié
telecharger("$BASE/VERSION", "$tmp/VERSION") or do { logm('dépôt injoignable, on réessaiera'); exit 0; };
my $v = lire("$tmp/VERSION"); $v =~ s/^\x{FEFF}//; $v =~ s/^\xEF\xBB\xBF//; $v =~ s/\r//g;
my ($rv, $rsha, $rsig) = $v =~ /^\s*v=(\d+)\s+sha256=([0-9a-f]{64})\s+sig=([0-9a-f]{64})\s*$/m
  or do { logm('fichier VERSION illisible'); exit 0; };
my $loc = 0;
{ my $t = lire("$DIR/VERSION"); $loc = $1 if defined $t && $t =~ /(\d+)/; }
exit 0 if $rv <= $loc;
if (hmac_sha256_hex("v=$rv:$rsha", $SECRET) ne $rsig) { logm("v$rv : signature invalide, ignorée"); exit 0; }

# anti-boucle : une version qui a échoué n'est pas retentée avant 6 h
my $ech = "$DIR/.maj-echec";
if (-f $ech) { my $e = lire($ech) // ''; if ($e =~ /^v=$rv\b/ && (-M $ech) * 24 < 6) { exit 0; } }
sub echec { my ($m) = @_; logm("v$rv : $m, mise à jour annulée (rien n'a été modifié)"); ecrire($ech, "v=$rv\n"); exit 0; }

# --- 2) paquet
telecharger("$BASE/godeye-maj.tgz", "$tmp/p.tgz") or echec('paquet injoignable');
my $tgz = lire("$tmp/p.tgz");
echec('empreinte différente') if sha256_hex($tgz) ne $rsha;
make_path("$tmp/x");
system('tar', '-xzf', "$tmp/p.tgz", '-C', "$tmp/x") == 0 or echec('archive illisible');

my @AUTORISES = (qr{^extension/(sidepanel\.js|sidepanel\.html|manifest\.json)$}, qr{^(godeye\.sh|fils\.pl|maj-consigne\.pl|maj-auto\.pl|recherche-cle\.txt|NOTES-MAJ\.txt)$}, qr{^script/Code\.gs\.modele$});
my @fichiers;
{
  my @pile = ('');
  while (@pile) {
    my $rel = shift @pile; my $abs = $rel eq '' ? "$tmp/x" : "$tmp/x/$rel";
    if (-l $abs) { echec("lien interdit $rel"); }
    if (-d $abs) { opendir(my $d, $abs) or echec('dossier illisible'); for my $n (sort grep { !/^\.\.?$/ } readdir $d) { push @pile, ($rel eq '' ? $n : "$rel/$n"); } closedir $d; }
    elsif (-f $abs) { push @fichiers, $rel; }
  }
}
echec('paquet vide') unless @fichiers;
for my $f (@fichiers) {
  echec("fichier non autorisé $f") unless grep { $f =~ $_ } @AUTORISES;
  echec("nom suspect $f") if $f =~ /\.\./ || $f =~ m{^/};
}

# --- 3) validation
for my $f (@fichiers) {
  my $p = "$tmp/x/$f";
  if ($f =~ /\.pl$/) { system("perl -c \Q$p\E >/dev/null 2>&1") == 0 or echec("syntaxe $f"); }
  if ($f eq 'godeye.sh') { system("bash -n \Q$p\E >/dev/null 2>&1") == 0 or echec('syntaxe godeye.sh'); }
  if ($f eq 'extension/sidepanel.js') {
    my $c = lire($p); echec('sidepanel.js trop court') if length($c) < 30000;
    echec('sidepanel.js incomplet') unless $c =~ /GE_CONFIG/ && $c =~ /window\.godeyeAdd/ && $c =~ /\}\)\(\);\s*$/;
  }
  if ($f eq 'extension/sidepanel.html') { my $c = lire($p); echec('sidepanel.html incomplet') unless $c =~ /config\.js/ && $c =~ /sidepanel\.js/ && $c =~ /<\/html>/; }
  if ($f eq 'extension/manifest.json') { my $j = eval { JSON::PP->new->decode(lire($p)) }; echec('manifest.json invalide') unless $j && ref $j eq 'HASH' && ($j->{manifest_version} // 0) == 3; }
}

# --- 4) sauvegarde de l'existant
my @t = localtime(); my $stamp = sprintf('%04d%02d%02d-%02d%02d', $t[5] + 1900, $t[4] + 1, $t[3], $t[2], $t[1]);
my $sv = "$DIR/sauvegardes-maj/v${loc}-$stamp";
for my $f (@fichiers) {
  next unless -f "$DIR/$f";
  make_path(dirname("$sv/$f"));
  copy("$DIR/$f", "$sv/$f");
}
{
  my $r = "$DIR/sauvegardes-maj";
  if (opendir(my $d, $r)) { my @s = sort grep { /^v/ } readdir $d; closedir $d; while (@s > 5) { remove_tree("$r/" . shift @s); } }
}

# --- 5) installation (écriture à côté, puis renommage : jamais de fichier à moitié écrit)
my @faits;
for my $f (@fichiers) {
  my $dest = "$DIR/$f";
  make_path(dirname($dest));
  my $new = "$dest.maj-new";
  copy("$tmp/x/$f", $new) or do { for my $g (@faits) { copy("$sv/$g", "$DIR/$g") if -f "$sv/$g"; } echec("copie impossible $f"); };
  chmod(($f =~ /\.sh$/ ? 0755 : 0644), $new);
  rename($new, $dest) or do { unlink $new; for my $g (@faits) { copy("$sv/$g", "$DIR/$g") if -f "$sv/$g"; } echec("remplacement impossible $f"); };
  push @faits, $f;
}
ecrire("$DIR/VERSION", "$rv\n");
make_path("$DIR/extension"); ecrire("$DIR/extension/version.txt", "$rv\n");
unlink $ech if -f $ech;
system('perl', 'maj-consigne.pl', 'consigne.md') if -f "$DIR/maj-consigne.pl" && -f "$DIR/consigne.md";
logm("passée de v$loc à v$rv");

# --- 6) notes de version et étape éventuelle dans le script Google
my %N;
if (open(my $h, '<:encoding(UTF-8)', "$DIR/NOTES-MAJ.txt")) { while (my $l = <$h>) { $l =~ s/\r?\n$//; $N{$1} = $2 if $l =~ /^([A-Z_]+)=(.*)$/; } close $h; }
my $msg = $N{RESUME} || 'Mise à jour installée. Recharge l’extension si le panneau ne le fait pas seul.';
my $sg_dist = $N{SCRIPT_GOOGLE} // 0;
my $sg_loc = lire("$DIR/.script-google-notifie");
# point de départ : l'étape fixée à l'installation (maj.conf, SCRIPT_GOOGLE_FAIT), puis la dernière notifiée
$sg_loc = defined $sg_loc && $sg_loc =~ /(\d+)/ ? $1 : (($C{SCRIPT_GOOGLE_FAIT} // '') =~ /^(\d+)$/ ? $1 : 0);
if ($sg_dist > $sg_loc && -f "$DIR/script/Code.gs.modele") {
  my $cfg = lire("$DIR/extension/config.js") // '';
  my ($adr) = $cfg =~ /MAIL:\s*'([^']*)'/; my ($tok) = $cfg =~ /TOKEN:\s*'([^']*)'/;
  $tok ||= do { my $j = lire("$DIR/.jeton-script") // ''; $j =~ s/\s+//g; $j };
  my $gs = lire("$DIR/script/Code.gs.modele");
  utf8::decode($gs);
  if ($adr && $tok) {
    $gs =~ s/(var GE_ADR = ')[^']*(')/$1$adr$2/; $gs =~ s/(var GE_TOKEN = ')[^']*(')/$1$tok$2/;
    utf8::encode($gs);
    ecrire("$DIR/script/Code.gs", $gs);
    ecrire("$DIR/A-FAIRE-script-google.txt", <<"TXT");
God Eye : une étape à faire dans ton script Google (une fois, 3 minutes)

1. Ouvre script.google.com avec ton compte pro, ton projet God Eye, fichier Code.gs.
2. Sélectionne tout son contenu, supprime, puis colle le contenu du fichier script/Code.gs de ton dossier GodEye (ton adresse et ton jeton y sont déjà remplis).
3. Si tu avais modifié les lignes GE_IGNORER_EXPEDITEUR ou GE_IGNORER_OBJET, remets tes valeurs.
4. Enregistre. Puis Déployer > Gérer les déploiements > crayon > Version : Nouvelle version > Déployer.
   Surtout pas « Nouveau déploiement » : l'adresse changerait.
5. Accepte l'autorisation si Google la demande.
Tant que ce n'est pas fait, les nouveautés qui passent par le script Google ne fonctionnent pas. Le reste marche déjà.
TXT
    ecrire("$DIR/.script-google-notifie", "$sg_dist\n");
    $msg .= ' Une étape reste à faire dans ton script Google : voir A-FAIRE-script-google.txt dans le dossier GodEye.';
  } else { logm('script Google : adresse ou jeton introuvable dans config.js'); }
}
notif('God Eye', "v$rv. $msg");
exit 0;
# test de publication automatique 2026-11-09
